# Генерируем данные

generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='supply', saleLevel = 50, days = 7,name = 'store1_in1.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='supply', saleLevel = 100, days = 7, name = 'store2_in2.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='supply', saleLevel = 50, days = 7, name = 'store3_in3.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='supply', saleLevel = 70, days = 7, name = 'store4_in4.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='supply', saleLevel = 50, days = 7,name = 'store5_in5.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='supply', saleLevel = 50, days = 7,name = 'store6_in6.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='supply', saleLevel = 50, days = 7,name = 'store7_in7.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='supply', saleLevel = 50, days = 7,name = 'store8_in8.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='supply', saleLevel = 50, days = 7, name = 'store9_in9.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='supply', saleLevel = 50, days = 7, name = 'store10_in10.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='sale', saleLevel = 70, days = 7, name = 'store1_out1.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='sale', saleLevel = 50, days = 7,name = 'store2_out2.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='sale', saleLevel = 50, days = 7, name = 'store3_out3.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='sale', saleLevel =25, days = 7, name = 'store4_out4.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='sale', saleLevel = 50, days = 7,name = 'store5_out5.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='sale', saleLevel = 75, days = 7, name = 'store6_out6.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='sale', saleLevel = 50, days = 7, name = 'store7_out7.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='sale', saleLevel = 100, days = 7, name = 'store8_out8.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='sale', saleLevel = 90, days = 7, name = 'store9_out9.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ/", type='sale', saleLevel = 5, days = 7, name = 'store10_out10.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
getwd()
setwd("/Users/tatyana/Desktop/Моя любовь R/Заварили/Анализ")
dir()

# Считываем данные

in1 <- read.table(file="store1_in1.txt", head=TRUE)
in2 <- read.table(file="store2_in2.txt", head=TRUE)
in3 <- read.table(file="store3_in3.txt", head=TRUE)
in4 <- read.table(file="store4_in4.txt", head=TRUE)
in5 <- read.table(file="store5_in5.txt", head=TRUE)
in6 <- read.table(file="store6_in6.txt", head=TRUE)
in7 <- read.table(file="store7_in7.txt", head=TRUE)
in8 <- read.table(file="store8_in8.txt", head=TRUE)
in9 <- read.table(file="store9_in9.txt", head=TRUE)
in10 <- read.table(file="store10_in10.txt", head=TRUE)
out1<- read.table(file="store1_out1.txt", head=TRUE)
out2 <- read.table(file="store2_out2.txt", head=TRUE)
out3 <- read.table(file="store3_out3.txt", head=TRUE)
out4 <- read.table(file="store4_out4.txt", head=TRUE)
out5 <- read.table(file="store5_out5.txt", head=TRUE)
out6 <- read.table(file="store6_out6.txt", head=TRUE)
out7 <- read.table(file="store7_out7.txt", head=TRUE)
out8 <- read.table(file="store8_out8.txt", head=TRUE)
out9 <- read.table(file="store9_out9.txt", head=TRUE)
out10 <- read.table(file="store10_out10.txt", head=TRUE)

# Проверяем, что продажи не превышают поставки. Меняем, если это необходимо

correct.data(in1,out1)
correct.data(in2,out2)
correct.data(in3,out3)
correct.data(in4,out4)
correct.data(in5,out5)
correct.data(in6,out6)
correct.data(in7,out7)
correct.data(in8,out8)
correct.data(in9,out9)
correct.data(in10,out10)

# Считываем цены

price1 <- read.table(file="store1_price.txt", head=TRUE) 
price2 <- read.table(file="store2_price.txt", head=TRUE) 
price3 <- read.table(file="store3_price.txt", head=TRUE) 
price4 <- read.table(file="store4_price.txt", head=TRUE) 
price5 <- read.table(file="store5_price.txt", head=TRUE) 
price6 <- read.table(file="store6_price.txt", head=TRUE) 
price7 <- read.table(file="store7_price.txt", head=TRUE) 
price8 <- read.table(file="store8_price.txt", head=TRUE) 
price9 <- read.table(file="store9_price.txt", head=TRUE) 
price10 <- read.table(file="store10_price.txt", head=TRUE) 

# Таближа стоимости продажи
P.new <- data.frame("Товар"=price1[,1],"Магазин 1"=price1[,3],"Магазин 2"=price2[,3],"Магазин 3"=price3[,3],"Магазин 4"=price4[,3],"Магазин 5"=price5[,3],"Магазин 6"=price6[,3],"Магазин 7"=price7[,3],"Магазин 8"=price8[,3],"Магазин 9"=price9[,3],"Магазин 10"=price10[,3]) 

# Таблица стоимости поставки 
P.supply.new <- data.frame("Товар"=price1[,1],"Магазин 1"=price1[,2],"Магазин 2"=price2[,2],"Магазин 3"=price3[,2],"Магазин 4"=price4[,2],"Магазин 5"=price5[,2],"Магазин 6"=price6[,2],"Магазин 7"=price7[,2],"Магазин 8"=price8[,2],"Магазин 9"=price9[,2],"Магазин 10"=price10[,2]) 

# Таблица стоимости утил
P.until.new <- data.frame("Товар"=price1[,1],"Магазин 1"=price1[,4],"Магазин 2"=price2[,4],"Магазин 3"=price3[,4],"Магазин 4"=price4[,4],"Магазин 5"=price5[,4],"Магазин 6"=price6[,4],"Магазин 7"=price7[,4],"Магазин 8"=price8[,4],"Магазин 9"=price9[,4],"Магазин 10"=price10[,4]) 

# Создаем саму таблицу
rev <- rep(0,(12+length(names(in1))-1))
profit <- rep(0, length(rev))
a <- names(in1)[2:length(names(in1))]
res.tab <- data.frame(" "=c("Магазин 1","Магазин 2","Магазин 3","Магазин 4","Магазин 5","Магазин 6","Магазин 7","Магазин 8","Магазин 9","Магазин 10",a,"Итого","Среднее"),"Выручка"=rev, "Прибыль"=profit)
sale <- rep(0, nrow(res.tab))
res.tab$Реализация <- sale 
res.tab["Реализация"] <- sale
res.tab$"Списание, конт." <- 0
res.tab$"Равномерность продаж" <- 0
res.tab$"Продажи макс" <- 0
День <- rep(0,nrow(res.tab))
res.tab <- cbind(res.tab, День)
res.tab$"Продажи мин" <- 0
День <- rep(0,nrow(res.tab))
res.tab <- cbind(res.tab, День)
res.tab$"Списание макс" <- 0
День <- rep(0,nrow(res.tab))
res.tab <- cbind(res.tab, День)
colnames(res.tab)[6] <- "sd"

# Продажи макс 

# Для магазина считаем все товары, которые продали. Для товара считаем по всем магазинам. 
for (day in (1:nrow(in1))) {
	for (prod in (2:ncol(in1))) {
		sold.prod <- (in1[day,prod] + in2[day,prod] + in3[day,prod] + in4[day,prod] + in5[day,prod] + in6[day,prod] + in7[day,prod] + in8[day,prod] + in9[day,prod] + in10[day,prod])
		if (res.tab[9+prod,7] < sold.prod){
			res.tab[9+prod,7]  <- sold.prod
			res.tab[9+prod,8] <- day
		}
	}
}	
updt(res.tab,in1)
updt(res.tab,in2)
updt(res.tab,in3)
updt(res.tab,in4)
updt(res.tab,in5)
updt(res.tab,in6)
updt(res.tab,in7)
updt(res.tab,in8)
updt(res.tab,in9)
updt(res.tab,in10)

# Продажи мин
# Сначала заполним все первыми попавшимися результатами. Проверяем, если есть лучше вариант, записываем его. Логика заполениния для магазина и товара схожа с продажи макс
res.tab[1,9] <- sum(in1[1,(2:ncol(in1))])
res.tab[2,9] <- sum(in2[1,(2:ncol(in1))])
res.tab[3,9] <- sum(in3[1,(2:ncol(in1))]) 
res.tab[4,9] <- sum(in4[1,(2:ncol(in1))]) 
res.tab[5,9] <- sum(in5[1,(2:ncol(in1))]) 
res.tab[6,9] <- sum(in6[1,(2:ncol(in1))]) 
res.tab[7,9] <- sum(in7[1,(2:ncol(in1))]) 
res.tab[8,9] <- sum(in8[1,(2:ncol(in1))]) 
res.tab[9,9] <- sum(in9[1,(2:ncol(in1))]) 
res.tab[10,9] <- sum(in10[1,(2:ncol(in1))]) 
res.tab[(1:10),10] <- 1
for (prod in (2:ncol(in1))) {
		res.tab[9+prod,9] <- (in1[1,prod] + in2[1,prod] + in3[1,prod] + in4[1,prod] + in5[1,prod] + in6[1,prod] + in7[1,prod] + in8[1,prod] + in9[1,prod] + in10[1,prod])
		res.tab[9+prod,10] <- 1
		}
# Обновим данные 
updmin(res.tab,1,in1)
updmin(res.tab,2,in2)
updmin(res.tab,3,in3)
updmin(res.tab,4,in4)
updmin(res.tab,5,in5)
updmin(res.tab,6,in6)
updmin(res.tab,7,in7)
updmin(res.tab,8,in8)
updmin(res.tab,9,in9)
updmin(res.tab,10,in10)
# Для продуктов отдельно обновим минимальные продажи
for (day in (1:nrow(in1))) {
	for (prod in (2:ncol(in1))) {
		sold.prod <- (in1[day,prod] + in2[day,prod] + in3[day,prod] + in4[day,prod] + in5[day,prod] + in6[day,prod] + in7[day,prod] + in8[day,prod] + in9[day,prod] + in10[day,prod])
		if (res.tab[9+prod,9] > sold.prod){
			res.tab[9+prod,9]  <- sold.prod
			res.tab[9+prod,10] <- day
		}
	}
}
# Реализация за все время 
#Считаем, сколько продали всего товаров для каждого магазина и сколько продали конкретный товар по всем магазинам. 
for (i in (2:ncol(in1))) {
	res.tab[1,4] <- res.tab[1,4] + sum(out1[,i])
	res.tab[2,4] <- res.tab[2,4] + sum(out2[,i])
	res.tab[3,4] <- res.tab[3,4] + sum(out3[,i])
	res.tab[4,4] <- res.tab[4,4] + sum(out4[,i])
	res.tab[5,4] <- res.tab[5,4] + sum(out5[,i])
	res.tab[6,4] <- res.tab[6,4] + sum(out6[,i])
	res.tab[7,4] <- res.tab[7,4] + sum(out7[,i])
	res.tab[8,4] <- res.tab[8,4] + sum(out8[,i])
	res.tab[9,4] <- res.tab[9,4] + sum(out9[,i])
	res.tab[10,4] <- res.tab[10,4] + sum(out10[,i])
	res.tab[9+i,4] <- sum(out1[,i]) + sum(out2[,i]) + sum(out3[,i]) + sum(out4[,i]) +sum(out5[,i]) + sum(out6[,i]) +sum(out7[,i]) + sum(out8[,i]) + sum(out9[,i]) + sum(out10[,i])
}
res.tab[(res.tab)-1,4] <- sum(res.tab[1:10,4])
res.tab[nrow(res.tab),4] <- mean(res.tab[1:10,4])
# Списание за все время 
for (i in (2:ncol(in1))) {
	res.tab[1,5] <- res.tab[1,5] + sum(in1[,i]) - sum(out1[,i])
	res.tab[2,5] <- res.tab[2,5] + sum(in2[,i]) - sum(out2[,i])
	res.tab[3,5] <- res.tab[3,5] + sum(in3[,i]) - sum(out3[,i])
	res.tab[4,5] <- res.tab[4,5] + sum(in4[,i]) - sum(out4[,i])
	res.tab[5,5] <- res.tab[5,5] + sum(in5[,i]) - sum(out5[,i])
	res.tab[6,5] <- res.tab[6,5] + sum(in6[,i]) - sum(out6[,i])
	res.tab[7,5] <- res.tab[7,5] + sum(in7[,i]) - sum(out7[,i])
	res.tab[8,5] <- res.tab[8,5] + sum(in8[,i]) - sum(out8[,i])
	res.tab[9,5] <- res.tab[9,5] + sum(in9[,i]) - sum(out9[,i])
	res.tab[10,5] <- res.tab[10,5] + sum(in10[,i]) - sum(out10[,i])
	res.tab[9+i,5] <- sum(in1[,i]) + sum(in2[,i]) + sum(in3[,i]) + sum(in4[,i]) + sum(in5[,i]) + sum(in6[,i]) + sum(in7[,i]) + sum(in8[,i]) +sum(in9[,i]) + sum(in10[,i]) - res.tab[9+i,4]
}
res.tab[nrow(res.tab)-1,5] <- sum(res.tab[1:10,5])
res.tab[nrow(res.tab),5] <- mean(res.tab[1:10,5])

# Выручка
# Продано товаров в каждом магазине магазине 
for (prod in (2:ncol(out1))) {
	res.tab[1,2] <- res.tab[1,2] + P.new[prod-1,2] * sum(out1[,prod])
	res.tab[2,2] <- res.tab[2,2] + P.new[prod-1,3] * sum(out2[,prod])
	res.tab[3,2] <- res.tab[3,2] + P.new[prod-1,4] * sum(out3[,prod])
	res.tab[4,2] <- res.tab[4,2] + P.new[prod-1,5] * sum(out4[,prod])
	res.tab[5,2] <- res.tab[5,2] + P.new[prod-1,6] * sum(out5[,prod])
	res.tab[6,2] <- res.tab[6,2] + P.new[prod-1,7] * sum(out6[,prod])
	res.tab[7,2] <- res.tab[7,2] + P.new[prod-1,8] * sum(out7[,prod])
	res.tab[8,2] <- res.tab[8,2] + P.new[prod-1,9] * sum(out8[,prod])
	res.tab[9,2] <- res.tab[9,2] + P.new[prod-1,10] * sum(out9[,prod])
	res.tab[10,2] <- res.tab[10,2] + P.new[prod-1,10] * sum(out10[,prod])
	res.tab[prod+9,2] <- P.new[prod-1,2] * (sum(out1[,prod])+sum(out2[,prod])+sum(out3[,prod])+sum(out4[,prod])+sum(out5[,prod])+sum(out6[,prod])+sum(out7[,prod])+sum(out8[,prod])+sum(out9[,prod])+sum(out10[,prod]))
}
res.tab[nrow(res.tab)-1,2] <- sum(res.tab[1:10,2])
res.tab[nrow(res.tab),2] <- mean(res.tab[1:10,2])
TC1 <- 0
TC2 <- 0
TC3 <- 0
TC4 <- 0
TC5 <- 0
TC6 <- 0
TC7 <- 0
TC8 <- 0
TC9 <- 0
TC10 <- 0
 
# Затраты 
for (prod in (2:ncol(in1))) {
	TC1 <- TC1 + (sum(in1[,prod]) * P.supply.new[prod,2]) + (out1[,prod] * P.until.new[prod,2]) 
	TC2 <- TC2 + (sum(in2[,prod]) * P.supply.new[prod,3]) + (out2[,prod] * P.until.new[prod,3]) 
	TC3 <- TC3 + (sum(in3[,prod]) * P.supply.new[prod,4]) + (out3[,prod] * P.until.new[prod,4]) 
	TC4 <- TC4 + (sum(in4[,prod]) * P.supply.new[prod,5]) + (out4[,prod] * P.until.new[prod,5]) 
	TC5 <- TC5 + (sum(in5[,prod]) * P.supply.new[prod,6]) + (out5[,prod] * P.until.new[prod,6]) 
	TC6 <- TC6 + (sum(in6[,prod]) * P.supply.new[prod,7]) + (out6[,prod] * P.until.new[prod,7]) 
	TC7 <- TC7 + (sum(in7[,prod]) * P.supply.new[prod,8]) + (out7[,prod] * P.until.new[prod,8]) 
	TC8 <- TC8 + (sum(in8[,prod]) * P.supply.new[prod,9]) + (out8[,prod] * P.until.new[prod,9]) 
	TC9 <- TC9 + (sum(in9[,prod]) * P.supply.new[prod,10]) + (out9[,prod] * P.until.new[prod,10]) 
	TC10 <- TC10 + (sum(in10[,prod]) * P.supply.new[prod,11]) + (out10[,prod] * P.until.new[prod,11]) 
}

# Прибыль +
res.tab[1,3] <- res.tab[1,2] - TC1
res.tab[2,3] <- res.tab[2,2] - TC2
res.tab[3,3] <- res.tab[3,2] - TC3
res.tab[4,3] <- res.tab[4,2] - TC4
res.tab[5,3] <- res.tab[5,2] - TC5
res.tab[6,3] <- res.tab[6,2] - TC6
res.tab[7,3] <- res.tab[7,2] - TC7
res.tab[8,3] <- res.tab[8,2] - TC8
res.tab[9,3] <- res.tab[9,2] - TC9
res.tab[10,3] <- res.tab[10,2] - TC10
res.tab[nrow(res.tab)-1,3] <- sum(res.tab[1:10,3])
res.tab[nrow(res.tab),3] <- mean(res.tab[1:10,3])

# Всего получили товаров 
prod <- 0
for (i in (2:ncol(in1))) {
	prod <- prod + sum(in1[,i]) + sum(in2[,i])  + sum(in3[,i]) + sum(in4[,i]) + sum(in5[,i]) + sum(in6[,i]) + sum(in7[,i]) + sum(in8[,i]) + sum(in9[,i]) + sum(in10[,i])
}
for (i in (2:ncol(in1))) {
	res.tab[i+9,3] <- res.tab[9+i,2] - (prod * P_supply + res.tab[9+i,5] * P_until)
}
# Равномерность +
for (i in (2:ncol(in1))) {
	res.tab[1,6] <- res.tab[1,6] + sd(out1[,i])
	res.tab[2,6] <- res.tab[2,6] + sd(out2[,i])
	res.tab[3,6] <- res.tab[3,6] + sd(out3[,i])
	res.tab[4,6] <- res.tab[4,6] + sd(out4[,i])
	res.tab[5,6] <- res.tab[5,6] + sd(out5[,i])
	res.tab[6,6] <- res.tab[6,6] + sd(out6[,i])
	res.tab[7,6] <- res.tab[7,6] + sd(out7[,i])
	res.tab[8,6] <- res.tab[8,6] + sd(out8[,i])
	res.tab[9,6] <- res.tab[9,6] + sd(out9[,i])
	res.tab[10,6] <- res.tab[10,6] + sd(out10[,i])
	res.tab[i+9,6] <- sd(out1[,i]) + sd(out2[,i]) + sd(out3[,i]) + sd(out4[,i]) + sd(out5[,i]) + sd(out6[,i]) + sd(out7[,i]) + sd(out8[,i]) + sd(out9[,i]) + sd(out10[,i])
}
res.tab[nrow(res.tab)-1,6] <- sum(res.tab[1:10,6])
res.tab[nrow(res.tab),6] <- mean(res.tab[1:10,6])

# Списание макс
for (day in (1:nrow(in1))) {
	for (prod in (2:ncol(in1))) {
		offs <- (in1[day,prod] + in2[day,prod] + in3[day,prod] + in4[day,prod] + in5[day,prod] + in6[day,prod] + in7[day,prod] + in8[day,prod] + in9[day,prod] + in10[day,prod]) - (out1[day,prod] + out2[day,prod] +out3[day,prod] + out4[day,prod] +out5[day,prod] + out6[day,prod] +out7[day,prod] + out8[day,prod] +out8[day,prod] + out10[day,prod])
		if (res.tab[9+prod,11] < offs){
			res.tab[9+prod,11]  <- offs
			res.tab[9+prod,12] <- day
		}
	}
	if (res.tab[1,11] < sum(in1[day,(2:ncol(in1))]) - sum(out1[day,(2:ncol(in1))])) {
		res.tab[1,11] <- sum(in1[day,(2:ncol(in1))]) - sum(out1[day,(2:ncol(in1))])
		res.tab[1,12] <- day
	}
	if (res.tab[2,11] < sum(in2[day,(2:ncol(in2))]) - sum(out2[day,(2:ncol(in2))])) {
		res.tab[2,11] <- sum(in2[day,(2:ncol(in2))]) - sum(out2[day,(2:ncol(in2))])
		res.tab[2,12] <- day
	}
	if (res.tab[3,11] < sum(in3[day,(2:ncol(in3))]) - sum(out3[day,(2:ncol(in1))])) {
		res.tab[3,11] <- sum(in3[day,(2:ncol(in3))]) - sum(out3[day,(2:ncol(in1))])
		res.tab[3,12] <- day
	}
	if (res.tab[4,11] < sum(in4[day,(2:ncol(in1))]) - sum(out4[day,(2:ncol(in1))])) {
		res.tab[4,11] <- sum(in4[day,(2:ncol(in1))]) - sum(out4[day,(2:ncol(in1))])
		res.tab[4,12] <- day
	}
	if (res.tab[5,11] < sum(in5[day,(2:ncol(in1))]) - sum(out5[day,(2:ncol(in1))])) {
		res.tab[5,11] <- sum(in5[day,(2:ncol(in1))]) - sum(out5[day,(2:ncol(in1))])
		res.tab[5,12] <- day
	}
	if (res.tab[6,11] < sum(in6[day,(2:ncol(in1))]) - sum(out6[day,(2:ncol(in1))])) {
		res.tab[6,11] <- sum(in6[day,(2:ncol(in1))]) - sum(out6[day,(2:ncol(in1))])
		res.tab[6,12] <- day
	}
	if (res.tab[7,11] < sum(in7[day,(2:ncol(in1))]) - sum(out7[day,(2:ncol(in1))])) {
		res.tab[7,11] <- sum(in7[day,(2:ncol(in1))]) - sum(out7[day,(2:ncol(in1))])
		res.tab[7,12] <- day
	}
	if (res.tab[8,11] < sum(in8[day,(2:ncol(in1))]) - sum(out8[day,(2:ncol(in1))])) {
		res.tab[8,11] <- sum(in8[day,(2:ncol(in1))]) - sum(out8[day,(2:ncol(in1))])
		res.tab[8,12] <- day
	}
	if (res.tab[9,11] < sum(in9[day,(2:ncol(in1))]) - sum(out9[day,(2:ncol(in1))])) {
		res.tab[9,11] <- sum(in9[day,(2:ncol(in1))]) - sum(out9[day,(2:ncol(in1))])
		res.tab[9,12] <- day
	}
	if (res.tab[10,11] < sum(in10[day,(2:ncol(in1))]) - sum(out10[day,(2:ncol(in1))])) {
		res.tab[10,11] <- sum(in10[day,(2:ncol(in1))]) - sum(out10[day,(2:ncol(in1))])
		res.tab[10,12] <- day
	}
}
# Избавимся от чисел в ненужных ячейках
res.tab[nrow(res.tab)-1,c(7:12)] <- ""
res.tab[nrow(res.tab),c(7:12)] <- ""


# Запись таблицы в файл
write.table(res.tab,file='/Users/tatyana/Desktop/Моя любовь R/Заварили/Result/Таблица2.csv',col.names=TRUE,row.names=FALSE,sep=';',dec=',', fileEncoding = 'UTF-8')


# Графика 
# Для молока в первом магазине посмотрим объем продаж по дням
# вычислим диапазон дней
xrange = range(out1[,1])
# диапазон по Оу
yrange = range(out1[,2], out1[,3], out1[,4])
# Построим пустой график, охватывающий полный диапазон данных
plot(xrange,
     yrange,
     main='Объем продаж молока в первом магазине', 
     xlab="День", 
     ylab="Количество проданного товара, шт",
     type = "n",
     cex.axis=0.8, 
     cex.lab=0.7, 
     cex.main=0.9) # n означает, что ряд данных рисоваться не будет
# Теперь добавим на график данные
points(out1[,1], out1[,2], pch=20, col="red3")
lines(out1[,1], out1[,2], pch=20, col="red3")

points(out1[,1], out1[,3], pch=22, col="forestgreen")
lines(out1[,1], out1[,3], pch=22, col="forestgreen")

points(out1[,1], out1[,4], pch=24, col="steelblue")
lines(out1[,1], out1[,4], pch=24, col="steelblue")
# Легенда
legend("topright", legend=names(out1)[2:ncol(out1)],col=c("red3", "forestgreen", "steelblue"), pch=c(20,22,24))


# Для молокаа во втором магазине посмотрим объем продаж по дням

dev.new()
plot(out2[,2], main='Объем продаж молока во втором магазине', xlab='День', ylab='Количество проданного товара, шт')
abline(v=out2[,1], col='blue')
abline(h=seq(0,100,5), col='blue')

# Выручка в первом магазине по дням 
# Считаем выручку по дням  
reven1 <- c()
for (day in (1:nrow(out1))) {
	reven1 <- append(reven1, (sum(out1[day,c(2:ncol(out1))]) * P)/1000)
}
reven2 <- c()
for (day in (1:nrow(out2))) {
	reven2 <- append(reven2, (sum(out2[day,c(2:ncol(out2))]) * P)/1000)
}
# Строим график 
dev.new()
#Первое 
#plot(reven1, main='Выручка по дням в первом магазине', xlab='День', ylab='Выручка, руб.',type='l')
#Вторая

# Построим пустой график, охватывающий полный диапазон данных
# вычислим диапазон дней
xrange = range(out1[,1])
# диапазон по Оу
yrange = range(reven1,reven2)
plot(xrange,
     yrange,
     main='Выручка по дням в первом магазине и во втором', 
     xlab="День", 
     ylab="Выручка, тыс.руб.",
     type = "n",
     cex.axis=0.8, 
     cex.lab=0.7, 
     cex.main=0.9) # n означает, что ряд данных рисоваться не будет
# Теперь добавим на график данные
points( c(1:length(reven1)),reven1, pch=20, col="red3")
lines(c(1:length(reven1)),reven1, pch=20, col="red3")

points(c(1:length(reven1)),reven2, pch=22, col="forestgreen")
lines(c(1:length(reven2)),reven2, pch=22, col="forestgreen")

# Легенда
legend("topright", legend=c("Первый","Второй"),col=c("red3", "forestgreen"), pch=c(20,22))

# Списание по дням в первом магазине (для второго и во втором магазине)
until1 <- c()
for (day in (1:nrow(in1))) {
	un <- sum(in1[day,c(2:ncol(in1))])  - sum(out1[day,c(2:ncol(out1))])
	until1 <- append(until1, un)
}
until2 <- c()
for (day in (1:nrow(in1))) {
	un <- sum(in2[day,c(2:ncol(in2))])  - sum(out2[day,c(2:ncol(out2))])
	until2 <- append(until2, un)
}
dev.new()
# Первое
#plot(until1, main='Списание по дням в первом магазине', xlab='День', ylab='Списание, шт.',type='b',fg='red',col='green')
#Второе
# вычислим диапазон дней
xrange = range(out1[,1])
# диапазон по Оу
yrange = range(until1, until2)
plot(xrange,
     yrange,
     main='Списание по дням в первом и втором магазине', 
     xlab="День", 
     ylab="Списание, шт.",
     type = "n",
     cex.axis=0.8, 
     cex.lab=0.7, 
     cex.main=0.9) # n означает, что ряд данных рисоваться не будет
# Теперь добавим на график данные
points( out1[,1], until1, pch=20, col="red3")
#lines(out1[,1], until1, pch=20, col="red3")

points(out2[,1], until2, pch=22, col="forestgreen")
#lines(out2[,1], until2, pch=22, col="forestgreen")

# Легенда
legend("topright", legend=c("Первый","Второй"),col=c("red3", "forestgreen"), pch=c(20,22))

# Прибыль по дням в первом магазине 
pr1 <- c()
for (day in (1:nrow(in1))) {
	TC <- sum(in1[day,c(2:ncol(in1))]) * P_supply + until1[day] * P_until
	pr1 <- append(pr1, (reven1[day] - TC) %/% 1000)
}
# Прибыль по дням во втором магазине 
pr2 <- c()
for (day in (1:nrow(in1))) {
	TC <- sum(in2[day,c(2:ncol(in2))]) * P_supply + until2[day] * P_until
	pr2 <- append(pr2, (reven2[day] - TC) %/% 1000)
}
dev.new()
plot(pr, main='Прибыль по дням в первом магазине', xlab='День', ylab='Прибыль, тыс.руб.',type='S')
# Рентабельность для первого магазина по дням (прибыль/выручка) * 100 (и потом и для второго)
dev.new()
rent1 <- c()
for (day in (1:nrow(in1))) {
	rent1 <- append(rent1, (pr1[day]/reven1[day])*100)
}
rent2 <- c()
for (day in (1:nrow(in2))) {
	rent2 <- append(rent2, (pr2[day]/reven2[day])*100)
}
# Первое 
#plot(pr, main='Рентабельность по дням в первом магазине', xlab='День', ylab='Рентабельность, %',type='s')
#Второе
# вычислим диапазон дней
xrange = range(out1[,1])
# диапазон по Оу
yrange = range(rent1, rent2)
plot(xrange,
     yrange,
     main='Рентабельность по дням в первом и втором магазине', 
     xlab="День", 
     ylab="Рентабельность, %",
     type = "n",
     cex.axis=0.8, 
     cex.lab=0.7, 
     cex.main=0.9) # n означает, что ряд данных рисоваться не будет
# Теперь добавим на график данные
#points( out1[,1], rent1, pch=20, col="red3")
lines(out1[,1], rent1, pch=20, col="red3")

#points(out2[,1], rent2, pch=22, col="forestgreen")
lines(out2[,1], rent2, pch=22, col="forestgreen")

# Легенда
legend("topright", legend=c("Первый","Второй"),col=c("red3", "forestgreen"))

