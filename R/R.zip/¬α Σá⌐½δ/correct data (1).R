correct.data <- function(inx,outx) {
	for (j in (2:ncol(inx))) {
		for (i in (1:nrow(inx))) {
			if (inx[i,j] < outx[i,j]) {
				a <- inx[i,j]
				inx[i,j] <- outx[i,j]
				outx[i,j] <- a
		}
	}
}
}