generate.sale.level = function(name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин",
                               type1 = "/in.txt",
                               flag = TRUE,
                               days = 7,
                               amount = 1,
                               title = c("Диван"),
                               saleLevel = 50){
  for (i in 1:10){
    inw = read.table(file = paste0(name, i, type1) ,
                     head = flag,
                     row.names = 1,
                     encoding = "UTF-8")
    outw = data.frame("День" = 1:days)
    for (j in 1:amount){
      outw$"head" = round(as.numeric(unlist(inw[j])) * saleLevel * 0.01)
      names(outw)[names(outw) == "head"] = title[j]
    }
    write.table(outw,
                file = paste0(name, i, "/out.txt"),
                quote = FALSE,
                row.names = FALSE,
                col.names = flag,
                sep = "	",
                fileEncoding = "UTF-8")
  }
}

{
  generate.sale.level(name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин", 
                      type1 = "/in.txt",
                      amount = 3,
                      title = c("Диван","Стол","Стул"))
}

