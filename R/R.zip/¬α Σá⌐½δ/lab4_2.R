
##создаем функцию с данными парметрами
generate.sale.level <- function(direction="C:/Users/eelis/Desktop/STUDY/R/LisenkovaElizaveta/TomatoShop/result/mag1", type='supply', saleLevel = 50, days = 7, name = 'iN.txt', logi = TRUE, product=c("Томаты","Черри", "Желтый томат")) {

	if(is.character(direction) == TRUE) {##проверка правильности пути файла
#
		#x <- c(1:kolprod)##создаем наименования товаров и вводим их названия
		#product <- c()
		#for (i in x) {
#
#			product <- append(product, readline('Введите товар: '))
#
#		}
		##колличество дней поставки
		y <- c(1:days)
		##количество товаров
		kolprodsupsale <- length(product) #(1:kolprod)
		##массив значений поставки
		sup <- c()
		##массив продаж
		sale <- c()

		##проверка типа файла
		if (tolower(type) == 'supply') {
		##создание таблицы для поставки
			inn <- data.frame('Days' = y)
		##случайные значения поставки для каждого продукта
			for (i in (1:kolprodsupsale)) {
			sup <- sample(10:100, days)
			inn[product[i]] <- sup
		}
		##выводим таблицу
		write.table(inn, file = paste0(direction, name), quote = FALSE, col.names = logi, sep = ' ', dec = ',')
		##если другой тип, то
		} else if (tolower(type == 'sale')) {
		##создаем другой
		outt <- data.frame('Days' = y)
		for (i in (1:kolprodsupsale)) {
		sup <- sample(10:100, days)
		##используем saleLevel
		sale <- round(sup * saleLevel / 100)
		outt[product[i]] <- sale
		}

	write.table(outt, file = paste0(direction,name), quote = FALSE, col.names = logi, sep = ' ', dec = ',')
	##иначе
	} else {
	print('Во втором параметре укажите "sale" или "supply"')

	}

	} else {
	print('Первым параметром введите путь и имя файла')
	}
}