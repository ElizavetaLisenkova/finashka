print(round((runif(10)*35-7)))
