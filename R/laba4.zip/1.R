vector <- c(1L, 2L, 3L)
typeof(vector)
mode(vector)
str(vector)
