sample(-7:-2,20, replace=T)
