v1 <- c(NULL)
v2 <- c(FALSE, NULL)
v3 <- c(TRUE, 3L, NULL)
v4 <- c(4.4, TRUE, 1L, NULL)
v5 <- c(5L, "abc", 3.2, TRUE, NULL)

typeof(v1)
typeof(v2)
typeof(v3)
typeof(v4)
typeof(v5)

# character - double - integer - logical - NULL