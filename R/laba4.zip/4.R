v1 <- c(2L)
v2 <- c(4L)
v1+v2
v1-v2
v1*v2
v1/v2

v1 <- c(2L, 4L)
v2 <- c(2L)
v1+v2
v1-v2
v1*v2
v1/v2

v1 <- c(3.0, 4L)
v2 <- c(8L, TRUE)
v1+v2
v1-v2
v1*v2
v1/v2

v1 <- c(FALSE, TRUE, 9L, 4.5)
v2 <- c(NULL, 6L)
v1+v2
v1-v2
v1*v2
v1/v2

