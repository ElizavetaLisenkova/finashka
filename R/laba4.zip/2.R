a <- c(7:4, 0)
b <- c(8, 10.5, 0, -2, 9)
a+b
a*b
a/b
mean(a)
mean(b)
sum(a)
sum(b)
print(a)
paste(a)
paste0(a)
print(b)
paste(b)
paste0(b)