{
  #переходим в папку Анализ
  setwd("C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/анализ")
  #проверяем ее содержимое
  dir()
  #присваиваем переменным значения таблиц
  in1 <-
    read.table(
      file = "store1_in.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  out1 <-
    read.table(
      file = "store1_out.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  in2 <-
    read.table(
      file = "store2_in.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  out2 <-
    read.table(
      file = "store2_out.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  in3 <-
    read.table(
      file = "store3_in.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  out3 <-
    read.table(
      file = "store3_out.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  in4 <-
    read.table(
      file = "store4_in.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  out4 <-
    read.table(
      file = "store4_out.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  in5 <-
    read.table(
      file = "store5_in.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  out5 <-
    read.table(
      file = "store5_out.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  in6 <-
    read.table(
      file = "store6_in.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  out6 <-
    read.table(
      file = "store6_out.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  in7 <-
    read.table(
      file = "store7_in.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  out7 <-
    read.table(
      file = "store7_out.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  in8 <-
    read.table(
      file = "store8_in.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  out8 <-
    read.table(
      file = "store8_out.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  in9 <-
    read.table(
      file = "store9_in.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  out9 <-
    read.table(
      file = "store9_out.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  in10 <-
    read.table(
      file = "store10_in.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  out10 <-
    read.table(
      file = "store10_out.txt",
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
  #проверим содержимое некоторых переменных
  print(in1)
  print(out1)
  print(in2)
  print(out2)
  print(in10)
  print(out10)
  #создаем таблицу
  #создаем первый столбец
  rev <- rep(0, 12)
  #создаем второй столбец
  profit <- rep(0, length(rev))
  #объединяем два столбца в таблицу
  res.tab <- data.frame(Выручка     = rev,     Прибыль     = profit)
  #создаем остальные столбцы
  res.tab$Реализация     <- 0
  res.tab$Списание     <- 0
  res.tab$"Равномерность продаж" <- 0
  res.tab["Продажи макс"] <- 0
  res.tab["День"] <- 0
  res.tab["Продажи мин"] <- 0
  res.tab["Д"] <- 0
  names(res.tab)[names(res.tab) == "Д"] <- "День"
  res.tab["Списание макс"] <- 0
  res.tab["Де"] <- 0
  names(res.tab)[names(res.tab) == "Де"] <- "День"
  #переименуем 1-ый столбец
  rownames(res.tab) <-
    c(
      "Магазин1",
      "Магазин2",
      "Магазин3",
      "Магазин4",
      "Магазин5",
      "Магазин6",
      "Магазин7",
      "Магазин8",
      "Магазин9",
      "Магазин10",
      "Итого",
      "Среднее"
    )
  #переименуем столбец "Равномерность продаж"
  colnames(res.tab)[colnames(res.tab) == "Равномерность продаж"] <-
    "sd"
  print(res.tab)
  #переменная со значением цены закупки одного контейнера
  P_s <- 5500
  #переменная со значением выручки от продажи контейнера
  P <- 8000
  #переменная со значением цены списания и утилизации непроданного контейнера
  P_u <- 400
  #создадим 2 таблицы со значениями поставок(ins) и продаж(outs)
  outs <-
    data.frame(
      out1$Продажа,
      out2$Продажа,
      out3$Продажа,
      out4$Продажа,
      out5$Продажа,
      out6$Продажа,
      out7$Продажа,
      out8$Продажа,
      out9$Продажа,
      out10$Продажа
    )
  ins <-
    data.frame(
      in1$Поставка,
      in2$Поставка,
      in3$Поставка,
      in4$Поставка,
      in5$Поставка,
      in6$Поставка,
      in7$Поставка,
      in8$Поставка,
      in9$Поставка,
      in10$Поставка
    )
  #заполняем столбец Реализация()
  for (i in 1:10) {
    res.tab[i, 3] <- sum(outs[i])
  }
  res.tab[11, 3] <- sum(res.tab[1:10, 3])
  res.tab[12, 3] <- mean(res.tab[1:10, 3])
  #заполняем столбец Выручка(TR)
  for (i in 1:10) {
    res.tab[i, 1] <- sum(res.tab[i, 3] * P)
  }
  res.tab[11, 1] <- sum(res.tab[1:10, 1])
  res.tab[12, 1] <- mean(res.tab[1:10, 1])
  #заполняем столбец Списание(Q_util)
  for (i in 1:10) {
    res.tab[i, 4] <- sum(ins[i] - outs[i])
  }
  res.tab[11, 4] <- sum(res.tab[1:10, 4])
  res.tab[12, 4] <- mean(res.tab[1:10, 4])
  #заполняем столбец Прибыль(Pr)
  for (i in 1:10) {
    res.tab[i, 2] <-
      sum(res.tab[i, 1] - ins[i] * P_s - res.tab[i, 4] * P_u)
  }
  res.tab[11, 2] <- sum(res.tab[1:10, 2])
  res.tab[12, 2] <- mean(res.tab[1:10, 2])
  print(res.tab)
  #заполняем столбец Продажи макс
  for (i in 1:10) {
    y <-
      c(outs[1, i], outs[2, i], outs[3, i], outs[4, i], outs[5, i], outs[6, i], outs[7, i])
    res.tab[i, 6] <- max(y)
    res.tab[i, 7] <- which.max(y)
    res.tab[i, 8] <- min(y)
    res.tab[i, 9] <- which.min(y)
    x <- ins[i] - outs[i]
    x <- c(x[1:7, 1])
    res.tab[i, 10] <- max(x)
    res.tab[i, 11] <- which.max(x)
  }
  #заполняем столбец sd
  for (i in 1:10) {
    a <-
      c(outs[1, i], outs[2, i], outs[3, i], outs[4, i], outs[5, i], outs[6, i], outs[7, i])
    print(a)
    res.tab[i, 5] <- sd(a)
  }
  res.tab[11, 5] <- sum(res.tab[1:10, 5])
  res.tab[12, 5] <- mean(res.tab[1:10, 5])
  print(res.tab)
  
  write.table(
    res.tab,
    file = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/resultTab.csv",
    col.names = TRUE,
    row.names = FALSE,
    sep = ';',
    dec = ','
  )
}

#КОНТРОЛЬНАЯ РАБОТА ЧАСТЬ 3


setwd("C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/")

tort<-function(input, sale){       # функция, позволяющая продажам не превышать поставки 
  for (i in 1:7){
    if (input[i] < sale[i]){
      sale[i] <- sample(35:input[i], size = 1)
    }
  }
  return(sale)     
}

generate.supply.sale <-        #функция, генирирующая файлы in.txt и out.txt
  function(name, type, min_gener, max_gener, flag) {
    setwd("C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/")
    a <- c(1:7)
    x <- as.integer(sample(min_gener:max_gener, size = 7))
    y <- as.integer(sample(min_gener:max_gener, size = 7))
    if (type == 1) {
      in1 <- data.frame("День" = a, "Поставка" = x)
      write.table(in1, file = name, row.names = FALSE, sep = "     ")
    }
    else if (type == 2) {
      out <- data.frame("День" = a, "Продажа" = y)
      write.table(out,
                  file = name,
                  row.names = FALSE,
                  sep = "     "
      )
    }
  }

#дальше будет вызов функций для того,  чтобы в папках Магазин1-Магазин 10 появились файлы in.txt и out.txt(продажа и поставки ).Можно было вызвать с помощью цикла, но я захотел так

generate.supply.sale(
  name = "магазин1/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин1/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин1")
in1 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out1 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out1$Продажа <- tort(in1$Поставка, out1$Продажа)
write.table(out1, file = "out.txt",row.names = FALSE,
            sep = "     ")
generate.supply.sale(
  name = "магазин2/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин2/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин2")
in2 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out2 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out2$Продажа <- tort(in2$Поставка, out2$Продажа)
write.table(out2, file = "out.txt",row.names = FALSE,
            sep = "     ")

generate.supply.sale(
  name = "магазин3/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин3/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин3")
in3 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out3 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out3$Продажа <- tort(in3$Поставка, out3$Продажа)
write.table(out3, file = "out.txt",row.names = FALSE,
            sep = "     ")

generate.supply.sale(
  name = "магазин4/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин4/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин4")
in4 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out4 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out4$Продажа <- tort(in4$Поставка, out4$Продажа)
write.table(out4, file = "out.txt",row.names = FALSE,
            sep = "     ")

generate.supply.sale(
  name = "магазин5/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин5/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин5")
in5 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out5 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out5$Продажа <- tort(in5$Поставка, out5$Продажа)
write.table(out5, file = "out.txt",row.names = FALSE,
            sep = "     ")

generate.supply.sale(
  name = "магазин6/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин6/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин6")
in6 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out6 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out6$Продажа <- tort(in6$Поставка, out6$Продажа)
write.table(out6, file = "out.txt",row.names = FALSE,
            sep = "     ")

generate.supply.sale(
  name = "магазин7/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин7/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин7")
in7 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out7 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out7$Продажа <- tort(in7$Поставка, out7$Продажа)
write.table(out7, file = "out.txt",row.names = FALSE,
            sep = "     ")

generate.supply.sale(
  name = "магазин8/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин8/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин8")
in8 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out8 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out8$Продажа <- tort(in8$Поставка, out8$Продажа)
write.table(out8, file = "out.txt",row.names = FALSE,
            sep = "     ")

generate.supply.sale(
  name = "магазин9/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин9/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин9")
in9 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out9 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out9$Продажа <- tort(in9$Поставка, out9$Продажа)
write.table(out9, file = "out.txt",row.names = FALSE,
            sep = "     ")

generate.supply.sale(
  name = "магазин10/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин10/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин10")
in10 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out10 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out10$Продажа <- tort(in10$Поставка, out10$Продажа)
write.table(out10, file = "out.txt",row.names = FALSE,
            sep = "     ")


#КОНТРОЛЬНАЯ РАБОТА ЧАСТЬ 4

setwd("C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop")



generate.supply.sale.many <- function(name, type='', min_gener=30, max_gener=55, flag=TRUE, suply_days=7, goods_amount=1, goods_name=c("Диван") ){ # Задаю функцию
  days_list = c("Понедельник","Вторник","Среда","Четверг","Пятница","Суббота","Воскресенье") # Задаю дни недели 
  days = c() 
  for (i in 1:suply_days) { 
  	    fromlist = i%%7 
    if ( i%%7 == 0) { 
      fromlist = 7 
          }
    days[i] = days_list[fromlist] 
  } 
  if (type == "in.txt") { 
    ttable = data.frame("День недели" = days) # таблица поставок
    for (i in 1:goods_amount) { 
      ttable$V <- sample(max_gener:max_gener,suply_days)  
      colnames(ttable)[colnames(ttable) == 'V'] <- goods_name[i] 
    }
    write.table(ttable, file = paste0(name,type), col.names=flag, sep = "\t", row.names=FALSE, fileEncoding= "utf-8") # Запись 
  } else if (type == "out.txt"){ 
    ttable = data.frame("День недели" = days) #  таблица продаж
    for (i in 1:goods_amount) { 
      ttable$V <- sample(min_gener:max_gener,suply_days) 
      colnames(ttable)[colnames(ttable) == 'V'] <- goods_name[i] 
    }
    write.table(ttable, file = paste0(name,type), col.names=flag, sep = "\t", row.names=FALSE, fileEncoding= "utf-8") # Запись
  } else { # Если не задан тип
    tablepost = data.frame("День недели" = days) #  таблица поставок
    tablepr = data.frame("День недели" = days) # таблица продаж
    for (i in 1:goods_amount) { # Прохожу по каждому товару
      ttable$V <- sample(min_gener:max_gener,suply_days) 
      colnames(tablepost)[colnames(tablepost) == 'V'] <- goods_name[i]
      ttable$V <- V-sample(0:10, 7) 
      colnames(tablepr)[colnames( tablepr) == 'V'] <- goods_name[i] 
    }
    write.table(tablepost, file = paste0(name,'in.txt'), col.names=flag, sep = "\t", row.names=FALSE, fileEncoding= "utf-8") # запись
    write.table(tablepr, file = paste0(name,'out.txt'), col.names=flag, sep = "\t", row.names=FALSE, fileEncoding= "utf-8") # запись
  }
}

generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин1/", 
  type = "in.txt", 
  min_gener = 35, max_gener= 55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин1/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин2/", 
  type = "in.txt", 
  min_gener = 35, max_gener =55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин2/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин3/", 
  type = "in.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин3/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин4/", 
  type = "in.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин4/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин5/", 
  type = "in.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин5/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин6/", 
  type = "in.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин6/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин7/", 
  type = "in.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин7/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин8/", 
  type = "in.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин8/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин9/", 
  type = "in.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин9/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин10/", 
  type = "in.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин10/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")

)


generate.sale.level = function(name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин",
                               type1 = "/in.txt",
                               flag = TRUE,
                               days = 7,
                               amount = 1,
                               title = c("Диван"),
                               saleLevel = 50){
  for (i in 1:10){
    inw = read.table(file = paste0(name, i, type1) ,
                     head = flag,
                     row.names = 1,
                     encoding = "UTF-8")
    outw = data.frame("День" = 1:days)
    for (j in 1:amount){
      outw$"head" = round(as.numeric(unlist(inw[j])) * saleLevel * 0.01)
      names(outw)[names(outw) == "head"] = title[j]
    }
    write.table(outw,
                file = paste0(name, i, "/out.txt"),
                quote = FALSE,
                row.names = FALSE,
                col.names = flag,
                sep = "	",
                fileEncoding = "UTF-8")
  }
}

{
  generate.sale.level(name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/магазин", 
                      type1 = "/in.txt",
                      amount = 3,
                      title = c("Диван","Стол","Стул"))
}

#кОНТРОЛЬНАЯ РАБОТА  ЧАСТЬ 7

{
  colo_for_mags = c("slateblue1", "palevioletred2", "plum3", "lightpink1", " darkseagreen ", "darkslateblue","darkorchid1","burlywood","cyan","gold")
  
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/анализ"
  
  generate.graphics2 <- function(name, days, amount, title, store) {
    sale = read.table(
      file = paste0(name, "/store", 1, "_out.txt"),
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
    plot(
      sale[, 1], type = "n", main = "Объем продаж по одному товару", xlab = "День", ylab = "Количество проданного товара"
    )
   
    for (i in store) {
      sale = read.table(
        file = paste0(name, "/store", i, "_out.txt"),
        head = TRUE,
        row.names = 1,
        encoding = "UTF-8"
      )
      for (j in 1:length(title)) {
        d = rep(100, days)
        tab = data.frame("объем продаж" = d)
        tab[, 1] = sale[, j]
        eval(parse(text = paste0('lines(1:', days, ', sale[, j], col = colo_for_mags[', i, '], cex = 1, pch = 19, bg = "ivory1", fg = "turquoise4", lty = 1, lwd = 5, type = "b")')))
      }
    }
  }
  
  generate.graphics2(
    name = name,
    days = 7,
    amount = 1,
    title = c("Диван"),
    store = 1:10
  )
   main = "Объем продаж"
  location = "topright"
  labels = c ("Магазин1", "Магазин2", "Магазин3","Магазин 4","Магазин5","Магазин6","Магазин7","Магазин8","Магазин9","Магазин10")
  colors = c("slateblue1", "palevioletred2", "plum3", "lightpink1", " darkseagreen ", "darkslateblue","darkorchid1","burlywood","cyan","gold")
legend(location, labels, title = main, fill=colors, bg = "white")
  
}

{
  
  name = "C:/Users/eelis/Desktop/STUDY/R/LisenkovaShop/анализ"
  
  colo_for_mags<- c("slateblue1", "palevioletred2", "plum3", "lightpink1", " darkseagreen ", "darkslateblue","darkorchid1","burlywood","cyan","gold")
  znak_for_mags<- c(21, 24)
  imena_tovarov<-c("Диван", "Стол")
  
  generate.graphics1 <- function(name, days, amount, title, store) {
    sale = read.table(
      file = paste0(name, "/store", 1, "_out.txt"),
      head = TRUE,
      row.names = 1,
      encoding = "UTF-8"
    )
    plot(
      sale[, 1], type = "n", main = "Объем продаж по двум товарам", xlab = "День", ylab = "Количество проданного товара"
    )
    for (i in store) {
      sale = read.table(
        file = paste0(name, "/store", i, "_out.txt"),
        head = TRUE,
        row.names = 1,
        encoding = "UTF-8"
      )
      for (j in 1:length(title)) {
        d = rep(100, days)
        tab = data.frame("объем продаж" = d)
        tab[, 1] = sale[, j]
        eval(parse(text = paste0('lines(1:', days, ', sale[, j], col = colo_for_mags[', i, '], cex = 1, pch = znak_for_mags[', j, '], bg = "ivory1", fg = "turquoise4", lty = 1, lwd = 5, type = "b")')))      }
    }
  }
  
  generate.graphics1(
    name = name,
    days = 7,
    amount = 2,
    title = imena_tovarov,
    store = 1:10
  )
  
  main = "Объем продаж"
  location = "topright"
  labels = c ("магазин1", "магазин2", "магазин3","магазин 4","магазин5","магазин6","магазин7","магазин8","магазин9","магазин10")
  colors = c("slateblue1", "palevioletred2", "plum3", "lightpink1", " darkseagreen ", "darkslateblue","darkorchid1","burlywood","cyan","gold")
  legend(location, labels, fill=colors, bg='white')
  legend("topleft", imena_tovarov, lty=1:1, col="black", bg='white', pch = c(21, 24))
  
  
  
}

