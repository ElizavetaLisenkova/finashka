days.ru <- c("понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье")
days.en <- c('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
en.l <- c('eng', 'english', 'англ', 'анг')
ru.l <- c('рус', 'ру', 'ru', 'rus')
func3 <- function(day,lang) {
  if (round(day)>7){
    if (is.element(tolower(lang),en.l)){
      return(print(days.en[day %% 7]))
    } else {
      return(print(days.ru[day %% 7]))
    }		
  } else if (round(day)<1) {
    return(print(" "))
  } else {
    if (is.element(tolower(lang),en.l)){
      return(print(days.en[round(day)]))
    } else {
      return(print(days.ru[round(day)]))
    }	
  }
}

func3(4, 'eng')
func3(6, 'англ')
func3(1, 'rus')
func3(3, 'ру')
