month.ru <- c('Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь')
month.en <- c('January', 'February', 'March', 'April', 'May', 'june', 'July', 'August', 'September', 'October', 'November', 'December')
en.l <- c('eng', 'english', 'англ', 'анг')
ru.l <- c('рус', 'ру', 'ru', 'rus')


func5 <- function(num,lang) {
  num = round(num)
  if (num < 1) {
    return(" ")
  }
  if (num > 12) {
    num = num %% 12	
  }
  if (is.element(tolower(lang), en.l)){
    return(month.en[num])
  } else {
    return(month.ru[num])
  }	
}

func6 <- function(num,lang,form='п') {
  monthname = func5(num,lang)
  if (form == 'к') {
    return(substr(monthname,1,3))
  }
  return(monthname)
}


func6(9, 'eng')
func6(6, 'rus', 'k')

