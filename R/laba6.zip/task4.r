days.ru <- c("понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье")
days.en <- c('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
en.l <- c('eng', 'english', 'англ', 'анг')
ru.l <- c('рус', 'ру', 'ru', 'rus')
func3 <- function(day,lang) {
  if (round(day)>7){
    if (is.element(tolower(lang),en.l)){
      return(print(days.en[day %% 7]))
    } else {
      return(print(days.ru[day %% 7]))
    }		
  } else if (round(day)<1) {
    return(print(" "))
  } else {
    if (is.element(tolower(lang),en.l)){
      return(print(days.en[round(day)]))
    } else {
      return(print(days.ru[round(day)]))
    }	
  }
}


func4 <- function(day,lang,form='п') {
  if (form == 'п') {
    return(func3(day,lang))
  }
  else {
    if (round(day)>7){
      if (is.element(tolower(lang),en.l)){
        return(print(substr(days.en[day %% 7],1,3)))
      } else {
        return(print(substr(days.ru[day %% 7],1,3)))
      }		
    } else if (round(day)<1) {
      return(print(" "))
    } else {
      if (is.element(tolower(lang),en.l)){
        return(print(substr(days.en[round(day)],1,3)))
      } else {
        return(print(substr(days.ru[round(day)],1,3)))
      }	
    }
  }
}
func4(4, 'eng','к')
func4(6, 'англ')
func4(1, 'rus')
func4(3, 'ру', 'к')
