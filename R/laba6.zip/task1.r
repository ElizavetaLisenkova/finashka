func <- function(x, y, z) {
	if (is.logical(x) | is.character(x) | is.logical(y) | is.character(y) | is.logical(z) | is.character(z)) {
		return(print("Неверный тип"))
	} else if (z == 0) {
		return(print("Деление на ноль"))
	} else {
		return(print(paste("Результат: ", round(x^y/z, 3)), quote = FALSE))
		}
}

func(2,4,4)
func("пятьсот",5,5)
func(8,2,0)