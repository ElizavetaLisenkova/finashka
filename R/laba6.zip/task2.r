weekdays <- c("понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье")
func2 <- function(n) {
  if (round(n)>7){
    return(print(weekdays[n%%7]))
  } else if (round(n)<1) {
    return(print("Нет"))
  } else {
    return(print(weekdays[round(n)]))
  }
}

func2(8)
func2(3)
func2(0)
