# Генерируем данные
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='supply', saleLevel = 50, days = 7,name = 'store1_in1.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='supply', saleLevel = 100, days = 7, name = 'store2_in2.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='supply', saleLevel = 50, days = 7, name = 'store3_in3.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='supply', saleLevel = 70, days = 7, name = 'store4_in4.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='supply', saleLevel = 50, days = 7,name = 'store5_in5.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='supply', saleLevel = 50, days = 7,name = 'store6_in6.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='supply', saleLevel = 50, days = 7,name = 'store7_in7.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='supply', saleLevel = 50, days = 7,name = 'store8_in8.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='supply', saleLevel = 50, days = 7, name = 'store9_in9.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='supply', saleLevel = 50, days = 7, name = 'store10_in10.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='sale', saleLevel = 70, days = 7, name = 'store1_out1.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='sale', saleLevel = 50, days = 7,name = 'store2_out2.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='sale', saleLevel = 50, days = 7, name = 'store3_out3.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='sale', saleLevel =25, days = 7, name = 'store4_out4.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='sale', saleLevel = 50, days = 7,name = 'store5_out5.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='sale', saleLevel = 75, days = 7, name = 'store6_out6.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='sale', saleLevel = 50, days = 7, name = 'store7_out7.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='sale', saleLevel = 100, days = 7, name = 'store8_out8.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='sale', saleLevel = 90, days = 7, name = 'store9_out9.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
generate.sale.level(direction="/Users/tatyana/Desktop/R/Zavarili/Analysis/", type='sale', saleLevel = 5, days = 7, name = 'store10_out10.txt', logi = TRUE,product=c("Молоко","Хлеб","Творог"))
getwd()
setwd("/Users/tatyana/Desktop/R/Zavarili/Analysis")
dir()
# Считываем данные
in1 <- read.table(file="store1_in1.txt", head=TRUE)
in2 <- read.table(file="store2_in2.txt", head=TRUE)
in3 <- read.table(file="store3_in3.txt", head=TRUE)
in4 <- read.table(file="store4_in4.txt", head=TRUE)
in5 <- read.table(file="store5_in5.txt", head=TRUE)
in6 <- read.table(file="store6_in6.txt", head=TRUE)
in7 <- read.table(file="store7_in7.txt", head=TRUE)
in8 <- read.table(file="store8_in8.txt", head=TRUE)
in9 <- read.table(file="store9_in9.txt", head=TRUE)
in10 <- read.table(file="store10_in10.txt", head=TRUE)
out1<- read.table(file="store1_out1.txt", head=TRUE)
out2 <- read.table(file="store2_out2.txt", head=TRUE)
out3 <- read.table(file="store3_out3.txt", head=TRUE)
out4 <- read.table(file="store4_out4.txt", head=TRUE)
out5 <- read.table(file="store5_out5.txt", head=TRUE)
out6 <- read.table(file="store6_out6.txt", head=TRUE)
out7 <- read.table(file="store7_out7.txt", head=TRUE)
out8 <- read.table(file="store8_out8.txt", head=TRUE)
out9 <- read.table(file="store9_out9.txt", head=TRUE)
out10 <- read.table(file="store10_out10.txt", head=TRUE)
# Проверяем, что продажи не превышают поставки. Меняем, если это необходимо
for (j in (2:ncol(in1))) {
	for (i in (1:nrow(in1))) {
		if (in1[i,j] < out1[i,j]) {
			a <- in1[i,j]
			in1[i,j] <- out1[i,j]
			out1[i,j] <- a
		}
			if (in2[i,j] < out2[i,j]) {
			a <- in2[i,j]
			in2[i,j] <- out2[i,j]
			out2[i,j] <- a
		}
			if (in3[i,j] < out3[i,j]) {
			a <- in1[i,j]
			in3[i,j] <- out3[i,j]
			out3[i,j] <- a
		}
			if (in4[i,j] < out4[i,j]) {
			a <- in1[i,j]
			in4[i,j] <- out4[i,j]
			out4[i,j] <- a
		}
			if (in5[i,j] < out5[i,j]) {
			a <- in5[i,j]
			in5[i,j] <- out5[i,j]
			out5[i,j] <- a
		}
			if (in6[i,j] < out6[i,j]) {
			a <- in6[i,j]
			in6[i,j] <- out6[i,j]
			out6[i,j] <- a
		}
			if (in7[i,j] < out7[i,j]) {
			a <- in7[i,j]
			in7[i,j] <- out7[i,j]
			out7[i,j] <- a
		}
			if (in8[i,j] < out8[i,j]) {
			a <- in8[i,j]
			in8[i,j] <- out8[i,j]
			out8[i,j] <- a
		}
			if (in9[i,j] < out9[i,j]) {
			a <- in9[i,j]
			in9[i,j] <- out9[i,j]
			out9[i,j] <- a
		}
			if (in10[i,j] < out10[i,j]) {
			a <- in10[i,j]
			in10[i,j] <- out10[i,j]
			out10[i,j] <- a
		}
	}
}

fixCost <- c(1000,800,660,870,1010,550,900,909,990,1100)
price1 <- read.table(file="store1_price.txt", head=TRUE) 
price2 <- read.table(file="store2_price.txt", head=TRUE) 
price3 <- read.table(file="store3_price.txt", head=TRUE) 
price4 <- read.table(file="store4_price.txt", head=TRUE) 
price5 <- read.table(file="store5_price.txt", head=TRUE) 
price6 <- read.table(file="store6_price.txt", head=TRUE) 
price7 <- read.table(file="store7_price.txt", head=TRUE) 
price8 <- read.table(file="store8_price.txt", head=TRUE) 
price9 <- read.table(file="store9_price.txt", head=TRUE) 
price10 <- read.table(file="store10_price.txt", head=TRUE) 
P <- 8000
# Таближа стоимости продажи
P.new <- data.frame("Товар"=price1[,1],"Магазин 1"=price1[,3],"Магазин 2"=price2[,3],"Магазин 3"=price3[,3],"Магазин 4"=price4[,3],"Магазин 5"=price5[,3],"Магазин 6"=price6[,3],"Магазин 7"=price7[,3],"Магазин 8"=price8[,3],"Магазин 9"=price9[,3],"Магазин 10"=price10[,3]) 

# Таблица стоимости поставки 
P.supply.new <- data.frame("Товар"=price1[,1],"Магазин 1"=price1[,2],"Магазин 2"=price2[,2],"Магазин 3"=price3[,2],"Магазин 4"=price4[,2],"Магазин 5"=price5[,2],"Магазин 6"=price6[,2],"Магазин 7"=price7[,2],"Магазин 8"=price8[,2],"Магазин 9"=price9[,2],"Магазин 10"=price10[,2]) 

# Таблица стоимости утил
P.until.new <- data.frame("Товар"=price1[,1],"Магазин 1"=price1[,4],"Магазин 2"=price2[,4],"Магазин 3"=price3[,4],"Магазин 4"=price4[,4],"Магазин 5"=price5[,4],"Магазин 6"=price6[,4],"Магазин 7"=price7[,4],"Магазин 8"=price8[,4],"Магазин 9"=price9[,4],"Магазин 10"=price10[,4]) 

P_supply <- 5500
P_until <-  400
# Создаем саму таблицу
rev <- rep(0,(12+length(names(in1))-1))
profit <- rep(0, length(rev))
a <- names(in1)[2:length(names(in1))]
res.tab <- data.frame(" "=c("Магазин 1","Магазин 2","Магазин 3","Магазин 4","Магазин 5","Магазин 6","Магазин 7","Магазин 8","Магазин 9","Магазин 10",a,"Итого","Среднее"),"Выручка"=rev, "Прибыль"=profit)
sale <- rep(0, nrow(res.tab))
res.tab$Реализация <- sale 
res.tab["Реализация"] <- sale
res.tab$"Списание, конт." <- 0
res.tab$"Равномерность продаж" <- 0
res.tab$"Продажи макс" <- 0
День <- rep(0,nrow(res.tab))
res.tab <- cbind(res.tab, День)
res.tab$"Продажи мин" <- 0
День <- rep(0,nrow(res.tab))
res.tab <- cbind(res.tab, День)
res.tab$"Списание макс" <- 0
День <- rep(0,nrow(res.tab))
res.tab <- cbind(res.tab, День)
colnames(res.tab)[6] <- "sd"

# Продажи макс
# Для магазина считаем все товары, которые продали. Для товара считаем по всем магазинам. 
for (day in (1:nrow(in1))) {
	for (prod in (2:ncol(in1))) {
		sold.prod <- (in1[day,prod] + in2[day,prod] + in3[day,prod] + in4[day,prod] + in5[day,prod] + in6[day,prod] + in7[day,prod] + in8[day,prod] + in9[day,prod] + in10[day,prod])
		if (res.tab[9+prod,7] < sold.prod){
			res.tab[9+prod,7]  <- sold.prod
			res.tab[9+prod,8] <- day
		}
	}
	if ( res.tab[1,7] < sum(in1[day,(2:ncol(in1))])) {
		res.tab[1,7] <- sum(in1[day,(2:ncol(in1))])
		res.tab[1,8] <- day
	}
		if ( res.tab[2,7] < sum(in2[day,(2:ncol(in2))])) {
		res.tab[2,7] <- sum(in2[day,(2:ncol(in2))])
		res.tab[2,8] <- day
	}
	if ( res.tab[3,7] < sum(in3[day,(2:ncol(in3))])) {
		res.tab[3,7] <- sum(in3[day,(2:ncol(in3))])
		res.tab[3,8] <- day
	}
	if ( res.tab[4,7] < sum(in4[day,(2:ncol(in4))])) {
		res.tab[4,7] <- sum(in4[day,(2:ncol(in4))])
		res.tab[4,8] <- day
	}
	if ( res.tab[4,7] < sum(in4[day,(2:ncol(in4))])) {
		res.tab[4,7] <- sum(in4[day,(2:ncol(in4))])
		res.tab[4,8] <- day
	}
	if ( res.tab[5,7] < sum(in5[day,(2:ncol(in5))])) {
		res.tab[5,7] <- sum(in5[day,(2:ncol(in5))])
		res.tab[5,8] <- day
	}
	if ( res.tab[6,7] < sum(in6[day,(2:ncol(in6))])) {
		res.tab[6,7] <- sum(in6[day,(2:ncol(in6))])
		res.tab[6,8] <- day
	}
	if ( res.tab[7,7] < sum(in7[day,(2:ncol(in7))])) {
		res.tab[7,7] <- sum(in7[day,(2:ncol(in7))])
		res.tab[7,8] <- day
	}
	if ( res.tab[8,7] < sum(in8[day,(2:ncol(in8))])) {
		res.tab[8,7] <- sum(in8[day,(2:ncol(in8))])
		res.tab[8,8] <- day
	}
	if ( res.tab[9,7] < sum(in9[day,(2:ncol(in9))])) {
		res.tab[9,7] <- sum(in9[day,(2:ncol(in9))])
		res.tab[9,8] <- day
	}
	if ( res.tab[10,7] < sum(in10[day,(2:ncol(in10))])) {
		res.tab[10,7] <- sum(in10[day,(2:ncol(in10))])
		res.tab[10,8] <- day
	}
}
# Продажи мин
# Сначала заполним все первыми попавшимися результатами. Проверяем, если есть лучше вариант, записываем его. Логика заполениния для магазина и товара схожа с продажи макс
res.tab[1,9] <- sum(in1[1,(2:ncol(in1))])
res.tab[2,9] <- sum(in2[1,(2:ncol(in1))])
res.tab[3,9] <- sum(in3[1,(2:ncol(in1))]) 
res.tab[4,9] <- sum(in4[1,(2:ncol(in1))]) 
res.tab[5,9] <- sum(in5[1,(2:ncol(in1))]) 
res.tab[6,9] <- sum(in6[1,(2:ncol(in1))]) 
res.tab[7,9] <- sum(in7[1,(2:ncol(in1))]) 
res.tab[8,9] <- sum(in8[1,(2:ncol(in1))]) 
res.tab[9,9] <- sum(in9[1,(2:ncol(in1))]) 
res.tab[10,9] <- sum(in10[1,(2:ncol(in1))]) 
res.tab[(1:10),10] <- 1
for (prod in (2:ncol(in1))) {
		res.tab[9+prod,9] <- (in1[1,prod] + in2[1,prod] + in3[1,prod] + in4[1,prod] + in5[1,prod] + in6[1,prod] + in7[1,prod] + in8[1,prod] + in9[1,prod] + in10[1,prod])
		res.tab[9+prod,10] <- 1
		}
for (day in (2:nrow(in1))) {
	for (prod in (2:ncol(in1))) {
		sold.prod <- (in1[day,prod] + in2[day,prod] + in3[day,prod] + in4[day,prod] + in5[day,prod] + in6[day,prod] + in7[day,prod] + in8[day,prod] + in9[day,prod] + in10[day,prod])
		if (res.tab[9+prod,9] > sold.prod){
			res.tab[9+prod,9]  <- sold.prod
			res.tab[9+prod,10] <- day
		}
	}

	if ( res.tab[1,9] > sum(in1[day,(2:ncol(in1))])) {
		res.tab[1,9] <- sum(in1[day,(2:ncol(in1))])
		res.tab[1,10] <- day
	}
		if ( res.tab[2,9] < sum(in2[day,(2:ncol(in2))])) {
		res.tab[2,9] <- sum(in2[day,(2:ncol(in2))])
		res.tab[2,10] <- day
	}
	if ( res.tab[3,9] > sum(in3[day,(2:ncol(in3))])) {
		res.tab[3,9] <- sum(in3[day,(2:ncol(in3))])
		res.tab[3,10] <- day
	}
	if ( res.tab[4,9] > sum(in4[day,(2:ncol(in4))])) {
		res.tab[4,9] <- sum(in4[day,(2:ncol(in4))])
		res.tab[4,10] <- day
	}
	if ( res.tab[4,9] > sum(in4[day,(2:ncol(in4))])) {
		res.tab[4,9] <- sum(in4[day,(2:ncol(in4))])
		res.tab[4,10] <- day
	}
	if ( res.tab[5,9] > sum(in5[day,(2:ncol(in5))])) {
		res.tab[5,9] <- sum(in5[day,(2:ncol(in5))])
		res.tab[5,10] <- day
	}
	if ( res.tab[6,9] > sum(in6[day,(2:ncol(in6))])) {
		res.tab[6,9] <- sum(in6[day,(2:ncol(in6))])
		res.tab[6,10] <- day
	}
	if ( res.tab[7,9] > sum(in7[day,(2:ncol(in7))])) {
		res.tab[7,9] <- sum(in7[day,(2:ncol(in7))])
		res.tab[7,10] <- day
	}
	if ( res.tab[8,9] > sum(in8[day,(2:ncol(in8))])) {
		res.tab[8,9] <- sum(in8[day,(2:ncol(in8))])
		res.tab[8,10] <- day
	}
	if ( res.tab[9,9] > sum(in9[day,(2:ncol(in9))])) {
		res.tab[9,9] <- sum(in9[day,(2:ncol(in9))])
		res.tab[9,10] <- day
	}
	if ( res.tab[10,9] > sum(in10[day,(2:ncol(in10))])) {
		res.tab[10,9] <- sum(in10[day,(2:ncol(in10))])
		res.tab[10,10] <- day
	}
}


# Реализация за все время 
#Считаем, сколько продали всего товаров для каждого магазина и сколько продали конкретный товар по всем магазинам. 
for (i in (2:ncol(in1))) {
	res.tab[1,4] <- res.tab[1,4] + sum(out1[,i])
	res.tab[2,4] <- res.tab[2,4] + sum(out2[,i])
	res.tab[3,4] <- res.tab[3,4] + sum(out3[,i])
	res.tab[4,4] <- res.tab[4,4] + sum(out4[,i])
	res.tab[5,4] <- res.tab[5,4] + sum(out5[,i])
	res.tab[6,4] <- res.tab[6,4] + sum(out6[,i])
	res.tab[7,4] <- res.tab[7,4] + sum(out7[,i])
	res.tab[8,4] <- res.tab[8,4] + sum(out8[,i])
	res.tab[9,4] <- res.tab[9,4] + sum(out9[,i])
	res.tab[10,4] <- res.tab[10,4] + sum(out10[,i])
	res.tab[9+i,4] <- sum(out1[,i]) + sum(out2[,i]) + sum(out3[,i]) + sum(out4[,i]) +sum(out5[,i]) + sum(out6[,i]) +sum(out7[,i]) + sum(out8[,i]) + sum(out9[,i]) + sum(out10[,i])
}
res.tab[nrow(res.tab)-1,4] <- sum(res.tab[1:10,4])
res.tab[nrow(res.tab),4] <- mean(res.tab[1:10,4])
# Списание за все время +
for (i in (2:ncol(in1))) {
	res.tab[1,5] <- res.tab[1,5] + sum(in1[,i]) - sum(out1[,i])
	res.tab[2,5] <- res.tab[2,5] + sum(in2[,i]) - sum(out2[,i])
	res.tab[3,5] <- res.tab[3,5] + sum(in3[,i]) - sum(out3[,i])
	res.tab[4,5] <- res.tab[4,5] + sum(in4[,i]) - sum(out4[,i])
	res.tab[5,5] <- res.tab[5,5] + sum(in5[,i]) - sum(out5[,i])
	res.tab[6,5] <- res.tab[6,5] + sum(in6[,i]) - sum(out6[,i])
	res.tab[7,5] <- res.tab[7,5] + sum(in7[,i]) - sum(out7[,i])
	res.tab[8,5] <- res.tab[8,5] + sum(in8[,i]) - sum(out8[,i])
	res.tab[9,5] <- res.tab[9,5] + sum(in9[,i]) - sum(out9[,i])
	res.tab[10,5] <- res.tab[10,5] + sum(in10[,i]) - sum(out10[,i])
	res.tab[9+i,5] <- sum(in1[,i]) + sum(in2[,i]) + sum(in3[,i]) + sum(in4[,i]) + sum(in5[,i]) + sum(in6[,i]) + sum(in7[,i]) + sum(in8[,i]) +sum(in9[,i]) + sum(in10[,i]) - res.tab[9+i,4]
}
res.tab[nrow(res.tab)-1,5] <- sum(res.tab[1:10,5])
res.tab[nrow(res.tab),5] <- mean(res.tab[1:10,5])
# Выручка 
a1<-0
a2<-0
a3<-0
a4<-0
a5<-0
a6<-0
a7<-0
a8<-0
a9<-0
a10<-0
# Продано товаров в каждом магазине магазине 
for (prod in (2:ncol(out1))) {
	a1 <- a1 + P.new[prod-1,2] * sum(out1[,prod])
	a2 <- a2 + P.new[prod-1,3] * sum(out2[,prod])
	a3 <- a3 + P.new[prod-1,4] * sum(out3[,prod])
	a4 <- a4 + P.new[prod-1,5] * sum(out4[,prod])
	a5 <- a5 + P.new[prod-1,6] * sum(out5[,prod])
	a6 <- a6 + P.new[prod-1,7] * sum(out6[,prod])
	a7 <- a7 + P.new[prod-1,8] * sum(out7[,prod])
	a8 <- a8 + P.new[prod-1,9] * sum(out8[,prod])
	a9 <- a9 + P.new[prod-1,10] * sum(out9[,prod])
	a10 <- a10 + P.new[prod-1,10] * sum(out10[,prod])
	res.tab[prod+9,2] <- P.new[prod-1,2] * (sum(out1[,prod])+sum(out2[,prod])+sum(out3[,prod])+sum(out4[,prod])+sum(out5[,prod])+sum(out6[,prod])+sum(out7[,prod])+sum(out8[,prod])+sum(out9[,prod])+sum(out10[,prod]))
}
	res.tab[1,2] <- a1
	res.tab[2,2] <- a2
	res.tab[3,2] <- a3
	res.tab[4,2] <- a4
	res.tab[5,2] <- a5
	res.tab[6,2] <- a6
	res.tab[7,2] <- a7
	res.tab[8,2] <- a8
	res.tab[9,2] <- a9
	res.tab[10,2] <-a10

res.tab[nrow(res.tab)-1,2] <- sum(res.tab[1:10,2])
res.tab[nrow(res.tab),2] <- mean(res.tab[1:10,2])

TC1 <- 0
TC2 <- 0
TC3 <- 0
TC4 <- 0
TC5 <- 0
TC6 <- 0
TC7 <- 0
TC8 <- 0
TC9 <- 0
TC10 <- 0

# Затраты переменные
for (prod in (2:ncol(in1))) {
	TC1 <- TC1 + (sum(in1[,prod]) * P.supply.new[prod-1,2]) + (sum(out1[,prod]) * P.until.new[prod-1,2]) 
	TC2 <- TC2 + (sum(in2[,prod]) * P.supply.new[prod-1,3]) + (sum(out2[,prod]) * P.until.new[prod-1,3]) 
	TC3 <- TC3 + (sum(in3[,prod]) * P.supply.new[prod-1,4]) + (sum(out3[,prod]) * P.until.new[prod-1,4]) 
	TC4 <- TC4 + (sum(in4[,prod]) * P.supply.new[prod-1,5]) + (sum(out4[,prod]) * P.until.new[prod-1,5]) 
	TC5 <- TC5 + (sum(in5[,prod]) * P.supply.new[prod-1,6]) + (sum(out5[,prod]) * P.until.new[prod-1,6]) 
	TC6 <- TC6 + (sum(in6[,prod]) * P.supply.new[prod-1,7]) + (sum(out6[,prod]) * P.until.new[prod-1,7]) 
	TC7 <- TC7 + (sum(in7[,prod]) * P.supply.new[prod-1,8]) + (sum(out7[,prod]) * P.until.new[prod-1,8]) 
	TC8 <- TC8 + (sum(in8[,prod]) * P.supply.new[prod-1,9]) + (sum(out8[,prod]) * P.until.new[prod-1,9]) 
	TC9 <- TC9 + (sum(in9[,prod]) * P.supply.new[prod-1,10]) + (sum(out9[,prod]) * P.until.new[prod-1,10]) 
	TC10 <- TC10 + (sum(in10[,prod]) * P.supply.new[prod-1,11]) + (sum(out10[,prod]) * P.until.new[prod-1,11]) 
}




# Прибыль = выручка - переменные затраты - постоянные затраты 
res.tab[1,3] <- res.tab[1,2] - TC1 - fixCost[1]
res.tab[2,3] <- res.tab[2,2] - TC2 - fixCost[2]
res.tab[3,3] <- res.tab[3,2] - TC3 - fixCost[3]
res.tab[4,3] <- res.tab[4,2] - TC4 - fixCost[4]
res.tab[5,3] <- res.tab[5,2] - TC5 - fixCost[5]
res.tab[6,3] <- res.tab[6,2] - TC6 - fixCost[6]
res.tab[7,3] <- res.tab[7,2] - TC7 - fixCost[7]
res.tab[8,3] <- res.tab[8,2] - TC8 - fixCost[8]
res.tab[9,3] <- res.tab[9,2] - TC9 - fixCost[9]
res.tab[10,3] <- res.tab[10,2] - TC10 - fixCost[10]
res.tab[nrow(res.tab)-1,3] <- sum(res.tab[1:10,3])
res.tab[nrow(res.tab),3] <- mean(res.tab[1:10,3])

# Всего заплатили за каждый товар за поставку
prod <- c()
for (i in (2:ncol(in1))) {
	prod <- append(prod, sum(in1[,i]) * P.supply.new[i-1,2] + sum(in2[,i]) * P.supply.new[i-1,3]  + sum(in3[,i])* P.supply.new[i-1,4] + sum(in4[,i])* P.supply.new[i-1,5] + sum(in5[,i])* P.supply.new[i-1,6] + sum(in6[,i])* P.supply.new[i-1,7] + sum(in7[,i])* P.supply.new[i-1,8] + sum(in8[,i])* P.supply.new[i-1,9] + sum(in9[,i])* P.supply.new[i-1,10] + sum(in10[,i])* P.supply.new[i-1,11])
}
# старый вариант с фиксированной ценой 
#for (i in (2:ncol(in1))) {
#	res.tab[i+9,3] <- res.tab[9+i,2] - (prod * P_supply[] + res.tab[9+i,5] * P_until)
#}
# Всего заплатили за списание каждого товара
spis <- c()
for (i in (2:ncol(in1))) {
	spis <- append(spis, sum(out1[,i]) * P.until.new[i-1,2] + sum(out2[,i]) * P.until.new[i-1,3]  + sum(out3[,i])* P.until.new[i-1,4] + sum(out4[,i])* P.until.new[i-1,5] + sum(out5[,i])* P.until.new[i-1,6] + sum(out6[,i])* P.until.new[i-1,7] + sum(out7[,i])* P.until.new[i-1,8] + sum(out8[,i])* P.until.new[i-1,9] + sum(out9[,i])* P.until.new[i-1,10] + sum(out10[,i])* P.until.new[i-1,11])
}
for (i in (2:ncol(in1))) {
	res.tab[i+9,3] <- res.tab[9+i,2] - (prod[i-1]  + spis[i-1])
}
# Равномерность +
for (i in (2:ncol(in1))) {
	res.tab[1,6] <- res.tab[1,6] + sd(out1[,i])
	res.tab[2,6] <- res.tab[2,6] + sd(out2[,i])
	res.tab[3,6] <- res.tab[3,6] + sd(out3[,i])
	res.tab[4,6] <- res.tab[4,6] + sd(out4[,i])
	res.tab[5,6] <- res.tab[5,6] + sd(out5[,i])
	res.tab[6,6] <- res.tab[6,6] + sd(out6[,i])
	res.tab[7,6] <- res.tab[7,6] + sd(out7[,i])
	res.tab[8,6] <- res.tab[8,6] + sd(out8[,i])
	res.tab[9,6] <- res.tab[9,6] + sd(out9[,i])
	res.tab[10,6] <- res.tab[10,6] + sd(out10[,i])
	res.tab[i+9,6] <- sd(out1[,i]) + sd(out2[,i]) + sd(out3[,i]) + sd(out4[,i]) + sd(out5[,i]) + sd(out6[,i]) + sd(out7[,i]) + sd(out8[,i]) + sd(out9[,i]) + sd(out10[,i])
}
res.tab[nrow(res.tab)-1,6] <- sum(res.tab[1:10,6])
res.tab[nrow(res.tab),6] <- mean(res.tab[1:10,6])
# Списание макс
for (day in (1:nrow(in1))) {
	for (prod in (2:ncol(in1))) {
		offs <- (in1[day,prod] + in2[day,prod] + in3[day,prod] + in4[day,prod] + in5[day,prod] + in6[day,prod] + in7[day,prod] + in8[day,prod] + in9[day,prod] + in10[day,prod]) - (out1[day,prod] + out2[day,prod] +out3[day,prod] + out4[day,prod] +out5[day,prod] + out6[day,prod] +out7[day,prod] + out8[day,prod] +out8[day,prod] + out10[day,prod])
		if (res.tab[9+prod,11] < offs){
			res.tab[9+prod,11]  <- offs
			res.tab[9+prod,12] <- day
		}
	}
	if (res.tab[1,11] < sum(in1[day,(2:ncol(in1))]) - sum(out1[day,(2:ncol(in1))])) {
		res.tab[1,11] <- sum(in1[day,(2:ncol(in1))]) - sum(out1[day,(2:ncol(in1))])
		res.tab[1,12] <- day
	}
	if (res.tab[2,11] < sum(in2[day,(2:ncol(in2))]) - sum(out2[day,(2:ncol(in2))])) {
		res.tab[2,11] <- sum(in2[day,(2:ncol(in2))]) - sum(out2[day,(2:ncol(in2))])
		res.tab[2,12] <- day
	}
	if (res.tab[3,11] < sum(in3[day,(2:ncol(in3))]) - sum(out3[day,(2:ncol(in1))])) {
		res.tab[3,11] <- sum(in3[day,(2:ncol(in3))]) - sum(out3[day,(2:ncol(in1))])
		res.tab[3,12] <- day
	}
	if (res.tab[4,11] < sum(in4[day,(2:ncol(in1))]) - sum(out4[day,(2:ncol(in1))])) {
		res.tab[4,11] <- sum(in4[day,(2:ncol(in1))]) - sum(out4[day,(2:ncol(in1))])
		res.tab[4,12] <- day
	}
	if (res.tab[5,11] < sum(in5[day,(2:ncol(in1))]) - sum(out5[day,(2:ncol(in1))])) {
		res.tab[5,11] <- sum(in5[day,(2:ncol(in1))]) - sum(out5[day,(2:ncol(in1))])
		res.tab[5,12] <- day
	}
	if (res.tab[6,11] < sum(in6[day,(2:ncol(in1))]) - sum(out6[day,(2:ncol(in1))])) {
		res.tab[6,11] <- sum(in6[day,(2:ncol(in1))]) - sum(out6[day,(2:ncol(in1))])
		res.tab[6,12] <- day
	}
	if (res.tab[7,11] < sum(in7[day,(2:ncol(in1))]) - sum(out7[day,(2:ncol(in1))])) {
		res.tab[7,11] <- sum(in7[day,(2:ncol(in1))]) - sum(out7[day,(2:ncol(in1))])
		res.tab[7,12] <- day
	}
	if (res.tab[8,11] < sum(in8[day,(2:ncol(in1))]) - sum(out8[day,(2:ncol(in1))])) {
		res.tab[8,11] <- sum(in8[day,(2:ncol(in1))]) - sum(out8[day,(2:ncol(in1))])
		res.tab[8,12] <- day
	}
	if (res.tab[9,11] < sum(in9[day,(2:ncol(in1))]) - sum(out9[day,(2:ncol(in1))])) {
		res.tab[9,11] <- sum(in9[day,(2:ncol(in1))]) - sum(out9[day,(2:ncol(in1))])
		res.tab[9,12] <- day
	}
	if (res.tab[10,11] < sum(in10[day,(2:ncol(in1))]) - sum(out10[day,(2:ncol(in1))])) {
		res.tab[10,11] <- sum(in10[day,(2:ncol(in1))]) - sum(out10[day,(2:ncol(in1))])
		res.tab[10,12] <- day
	}
}
# Избавимся от чисел в ненужных ячейках
res.tab[nrow(res.tab)-1,c(7:12)] <- ""
res.tab[nrow(res.tab),c(7:12)] <- ""


# Запись таблицы в файл
write.table(res.tab,file='/Users/tatyana/Desktop/R/Zavarili/Result/Tab3.csv',col.names=TRUE,row.names=FALSE,sep=';',dec=',', fileEncoding = 'UTF-8')


# Графика 
# Для молока в первом магазине посмотрим объем продаж по дням
# вычислим диапазон дней
xrange = range(out1[,1])
# диапазон по Оу
yrange = range(out1[,2], out1[,3], out1[,4])
# Построим пустой график, охватывающий полный диапазон данных
plot(xrange,
     yrange,
     main='Объем продаж молока в первом магазине', 
     xlab="День", 
     ylab="Количество проданного товара, шт",
     type = "n",
     cex.axis=0.8, 
     cex.lab=0.7, 
     cex.main=0.9) # n означает, что ряд данных рисоваться не будет
# Теперь добавим на график данные
points(out1[,1], out1[,2], pch=20, col="red3")
lines(out1[,1], out1[,2], pch=20, col="red3")

points(out1[,1], out1[,3], pch=22, col="forestgreen")
lines(out1[,1], out1[,3], pch=22, col="forestgreen")

points(out1[,1], out1[,4], pch=24, col="steelblue")
lines(out1[,1], out1[,4], pch=24, col="steelblue")
# Легенда
legend("topright", legend=names(out1)[2:ncol(out1)],col=c("red3", "forestgreen", "steelblue"), pch=c(20,22,24))


# Для молокаа во втором магазине посмотрим объем продаж по дням

dev.new()
plot(out2[,2], main='Объем продаж молока во втором магазине', xlab='День', ylab='Количество проданного товара, шт')
abline(v=out2[,1], col='blue')
abline(h=seq(0,100,5), col='blue')

# Выручка в первом магазине по дням 
# Считаем выручку по дням  
reven1 <- c()
for (day in (1:nrow(out1))) {
	for (prod in(2:ncol(out1))) {
		reven1 <- append(reven1, (sum(out1[day,prod]) * P.new[(prod-1),2])/1000)
	}
}
reven2 <- c()
for (day in (1:nrow(out2))) {
		for (prod in(2:ncol(out2))) {
		reven2 <- append(reven2, (sum(out2[day,prod]) * P.new[(prod-1),3])/1000)
	}
}
# Строим график 
dev.new()
#Первое 
plot(reven1, main='Выручка по дням в первом магазине', xlab='День', ylab='Выручка, руб.',type='o')
#Вторая
dev.new()
# Построим пустой график, охватывающий полный диапазон данных
# вычислим диапазон дней
xrange = range(out1[,1])
# диапазон по Оу
yrange = range(reven1,reven2)
plot(xrange,
     yrange,
     main='Выручка по дням в первом магазине и во втором', 
     xlab="День", 
     ylab="Выручка, тыс.руб.",
     type = "n",
     cex.axis=0.8, 
     cex.lab=0.7, 
     cex.main=0.9) # n означает, что ряд данных рисоваться не будет
# Теперь добавим на график данные
points( c(1:length(reven1)),reven1, pch=20, col="red3")
lines(c(1:length(reven1)),reven1, pch=20, col="red3")

points(c(1:length(reven1)),reven2, pch=22, col="forestgreen")
lines(c(1:length(reven2)),reven2, pch=22, col="forestgreen")

# Легенда
legend("topright", legend=c("Первый","Второй"),col=c("red3", "forestgreen"), pch=c(20,22))

# Списание по дням в первом магазине (для второго и во втором магазине)
until1 <- c()
for (day in (1:nrow(in1))) {
	un <- sum(in1[day,c(2:ncol(in1))])  - sum(out1[day,c(2:ncol(out1))])
	until1 <- append(until1, un)
}
until2 <- c()
for (day in (1:nrow(in1))) {
	un <- sum(in2[day,c(2:ncol(in2))])  - sum(out2[day,c(2:ncol(out2))])
	until2 <- append(until2, un)
}
dev.new()
# Первое
#plot(until1, main='Списание по дням в первом магазине', xlab='День', ylab='Списание, шт.',type='b',fg='red',col='green')
#Второе
# вычислим диапазон дней
xrange = range(out1[,1])
# диапазон по Оу
yrange = range(until1, until2)
plot(xrange,
     yrange,
     main='Списание по дням в первом и втором магазине', 
     xlab="День", 
     ylab="Списание, шт.",
     type = "n",
     cex.axis=0.8, 
     cex.lab=0.7, 
     cex.main=0.9) # n означает, что ряд данных рисоваться не будет
# Теперь добавим на график данные
points( out1[,1], until1, pch=20, col="red3")
#lines(out1[,1], until1, pch=20, col="red3")

points(out2[,1], until2, pch=22, col="forestgreen")
#lines(out2[,1], until2, pch=22, col="forestgreen")

# Легенда
legend("topright", legend=c("Первый","Второй"),col=c("red3", "forestgreen"), pch=c(20,22))

# Прибыль по дням в первом магазине 
pr1 <- c()
TC <- c()
TCC <- c()
for (day in (1:nrow(in1))) {
	for (prod in (2:ncol(in1))) {
		TC <- append(TC,sum(in1[day,prod]) * P.supply.new[(prod-1),2] + (sum(in1[day,prod])  - sum(out1[day,prod])) * P.until.new[(prod-1),2])
	}
	pr1 <- append(pr1, (reven1[day] - TC[day]) %/% 1000)
}
# Прибыль по дням во втором магазине 
pr2 <- c()
for (day in (1:nrow(in2))) {
	for (prod in (2:ncol(in2))) {
		TCC <- append(TCC,sum(in2[day,prod]) * P.supply.new[(prod-1),3] + (sum(in2[day,prod])  - sum(out2[day,prod])) * P.until.new[(prod-1),3])
	}
	pr2 <- append(pr2, (reven2[day] - TCC[day]) %/% 1000)
}
dev.new()
plot(pr2, main='Прибыль по дням в первом магазине', xlab='День', ylab='Прибыль, тыс.руб.',type='S')
# Рентабельность для первого магазина по дням (прибыль/выручка) * 100 (и потом и для второго)
dev.new()
rent1 <- c()
for (day in (1:nrow(in1))) {
	rent1 <- append(rent1, (pr1[day]/reven1[day])*100)
}
rent2 <- c()
for (day in (1:nrow(in2))) {
	rent2 <- append(rent2, (pr2[day]/reven2[day])*100)
}
# Первое 
#plot(pr1, main='Рентабельность по дням в первом магазине', xlab='День', ylab='Рентабельность, %',type='s')
#Второе
# вычислим диапазон дней
xrange = range(out1[,1])
# диапазон по Оу
yrange = range(rent1, rent2)
plot(xrange,
     yrange,
     main='Рентабельность по дням в первом и втором магазине', 
     xlab="День", 
     ylab="Рентабельность, %",
     type = "n",
     cex.axis=0.8, 
     cex.lab=0.7, 
     cex.main=0.9) # n означает, что ряд данных рисоваться не будет
# Теперь добавим на график данные
#points( out1[,1], rent1, pch=20, col="red3")
lines(out1[,1], rent1, pch=20, col="red3",lwd = 3, lty = 2)

#points(out2[,1], rent2, pch=22, col="forestgreen")
lines(out2[,1], rent2, pch=22, col="forestgreen",lwd = 3, lty = 2)

# Легенда
legend("bottomleft", legend=c("Первый","Второй"),col=c("red3", "forestgreen"),pch=c(20,22))

# С учетом постоянных затрат прибыль стала меньше


# Отсортированная таблица по возрастанию прибыли 
sort.tab <- res.tab[order(res.tab$Прибыль[1:10]),]
# Расчет премии для магазинов с положительной прибылью и штафов для магазинов с отрицательной. Если прибыль = 0, то не назначаем ни штраф, ни премию
# Учитывается рейтинг магазина. Чем лучше дела обстоят с прибылью, тем меньше штраф/ больше премия
# В исходной формуле мы не учитывали, что в больших магазинах прибыль выше. Если логприфмировать, то эта разница сглаживается
sort.tab$Премия <- rep(0,10)
sort.tab$Штраф <- rep(0,10)
for (i in (1:10)) {
	if (sort.tab[i,3] == 0){
		sort.tab[i,13] <- 0
		sort.tab[i,14] <- 0
	}
	else if (sort.tab[i,3] > 0) {
		#sort.tab[i,13] <- ((sort.tab[i,3] * abs (0.03 + i*0.02)))
		sort.tab[i,13] <- round(log(sort.tab[i,3]+1) * 1000)
	}
	else {
		#sort.tab[i,14] <- ((abs(sort.tab[i,3]) * abs (0.03 + (10-i)*0.02)))	
		sort.tab[i,14] <- round(log((abs(sort.tab[i,3])+1)) * 1000)
		}
}
# Построим график премий и штрафов. По Ох будет название магазина, по Оу сумма штрафа или премии
dev.new()
#new.tab <-  sort.tab[order(sort.tab[,1]),]
new.sort.tab <- data.frame("Номер магазина"=c("Магазин 1","Магазин 2","Магазин 3","Магазин 4","Магазин 5","Магазин 6","Магазин 7","Магазин 8","Магазин 9","Магазин 10"),"Премия"=rep(0,10),"Штраф"=rep(0,10))
for (i in (1:10)) {
	for (j in (1:10)) {
		if (sort.tab[i,1] == new.sort.tab[j,1]) {
			new.sort.tab[j,2] = sort.tab[i,13]
			new.sort.tab[j,3] = sort.tab[i,14]
		}
	}
}
# Для удобства отобразим только номер магазина по Ох
new.sort.tab[,1] <- c(1,2,3,4,5,6,7,8,9,10)
# Нрисуем точки с премией по магазинам
plot(new.sort.tab[,1],
     new.sort.tab[,2],
     main='Премия и штрафы', 
     xlab="День", 
     ylab="Рентабельность, %",
     type = "p",
     pch = 8,
     col = 'green',
     cex.axis=0.8, 
     cex.lab=0.7, 
     cex.main=0.9) 
 axis(side = 1, 
     at = seq(min(new.sort.tab[,1]), max(new.sort.tab[,1]), 1),
     tck = -0.02,
     labels = FALSE)
#Теперь добавим на график данные штрафов
points( new.sort.tab[,1], new.sort.tab[,3], pch=9, col="red")
axis(side = 1, 
     at = seq(min(new.sort.tab[,1]), max(new.sort.tab[,1]), 1),
     tck = -0.02,
     labels = TRUE)

legend("center", legend=c("Премия","Штраф"),col=c("green", "red"),pch=c(8,9))
