
generate.price <- function(direction,name.price,name.prod){
#name.price <-c('P_supply','P_until','P')
#name.file <-'price.txt'
#name.prod <-c('Молоко','Хлеб','Творог')
#direction <-'/Users/tatyana/Desktop/R/Zavarili/Shop 1/'
# Создаем таблицу: Для каждого продукта генерируем ценку поставки, продажи, утилизации с разными границами. Записываем в файл. 
name.file <-'price.txt'
price.tab <- data.frame('Продукт'=name.prod,'Поставка'=rep(0,length(name.prod)),'Продажа'=rep(0,length(name.prod)),'Утилизация'=rep(0,length(name.prod)))
for (prod in (1:length(name.prod))) {
	# Поставка
	price.tab[prod,2] <- sample(1000:5600,1)
	# Продажа
	price.tab[prod,3] <- sample(12500:45000,1)
	# Утилизация
	price.tab[prod,4] <- sample(100:300,1)
}
write.table(price.tab,file=paste0(direction, name.file),quote = FALSE,row.names=FALSE, col.names=TRUE,sep=' ',dec=',', fileEncoding = 'UTF-8')
}