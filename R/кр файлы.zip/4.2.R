setwd("/Users/violettakorotenko/Desktop/Korotenkocompany/")



generate.supply.sale.many <- function(name, type='', min_gener=30, max_gener=55, flag=TRUE, suply_days=7, goods_amount=1, goods_name=c("Диван") ){ # Задаю функцию
  days_list = c("Понедельник","Вторник","Среда","Четверг","Пятница","Суббота","Воскресенье") # Задаю дни недели 
  days = c() 
  for (i in 1:suply_days) { 
  	    fromlist = i%%7 
    if ( i%%7 == 0) { 
      fromlist = 7 
          }
    days[i] = days_list[fromlist] 
  } 
  if (type == "in.txt") { 
    ttable = data.frame("День недели" = days) # таблица поставок
    for (i in 1:goods_amount) { 
      ttable$V <- sample(max_gener:max_gener,suply_days)  
      colnames(ttable)[colnames(ttable) == 'V'] <- goods_name[i] 
    }
    write.table(ttable, file = paste0(name,type), col.names=flag, sep = "\t", row.names=FALSE, fileEncoding= "utf-8") # Запись 
  } else if (type == "out.txt"){ 
    ttable = data.frame("День недели" = days) #  таблица продаж
    for (i in 1:goods_amount) { 
      ttable$V <- sample(min_gener:max_gener,suply_days) 
      colnames(ttable)[colnames(ttable) == 'V'] <- goods_name[i] 
    }
    write.table(ttable, file = paste0(name,type), col.names=flag, sep = "\t", row.names=FALSE, fileEncoding= "utf-8") # Запись
  } else { # Если не задан тип
    tablepost = data.frame("День недели" = days) #  таблица поставок
    tablepr = data.frame("День недели" = days) # таблица продаж
    for (i in 1:goods_amount) { # Прохожу по каждому товару
      ttable$V <- sample(min_gener:max_gener,suply_days) 
      colnames(tablepost)[colnames(tablepost) == 'V'] <- goods_name[i]
      ttable$V <- V-sample(0:10, 7) 
      colnames(tablepr)[colnames( tablepr) == 'V'] <- goods_name[i] 
    }
    write.table(tablepost, file = paste0(name,'in.txt'), col.names=flag, sep = "\t", row.names=FALSE, fileEncoding= "utf-8") # запись
    write.table(tablepr, file = paste0(name,'out.txt'), col.names=flag, sep = "\t", row.names=FALSE, fileEncoding= "utf-8") # запись
  }
}

generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин1/", 
  type = "in.txt", 
  min_gener = 35, max_gener= 55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин1/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин2/", 
  type = "in.txt", 
  min_gener = 35, max_gener =55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин2/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин3/", 
  type = "in.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин3/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин4/", 
  type = "in.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин4/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин5/", 
  type = "in.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин5/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин6/", 
  type = "in.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин6/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин7/", 
  type = "in.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин7/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин8/", 
  type = "in.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин8/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин9/", 
  type = "in.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин9/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин10/", 
  type = "in.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")
)
generate.supply.sale.many( 
  name = "/Users/violettakorotenko/Desktop/Korotenkocompany/магазин10/", 
  type = "out.txt", 
  min_gener = 35, max_gener=55,
  flag = TRUE, 
  suply_days = 7, 
  goods_amount = 3, 
  goods_name = c("Диван", "Стул", "Стол")

)




