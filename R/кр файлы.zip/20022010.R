# 1
generate.supply.sale<-function(name = '/Users/tatyana/Desktop/Моя любовь R/Заварили/Заведение 1/', type='in.txt', m=1, M=1000, flag=T) {
	days <- c("Понедельник","Вторник","Среда","Четверг","Пятница","Суббота","Воскресенье") 
	dat <- sample(m:M,7)
	if (type == 'in.txt'){
		tab <- data.frame("День недели"=days,"Поставки"=dat)
	} else{
		tab <- data.frame("День недели"=days,"Продажа"=dat)
	}
     write.table(tab ,file=paste(name,type,sep=''), col.names=flag,row.names=FALSE,sep=' ',dec=',')
}
# 2
generate.supply.sale.many<-function(name = c('/Users/tatyana/Desktop/Моя любовь R/Заварили/Заведение 1/'), type='in.txt', m=1, M=1000, flag=T, days = 7, col=1, goods=c('Молоко')) {
	rev <- rep(0, days)
          pr <- rep(0, length(rev))
	if (type=='in.txt'){
		line <- data.frame('День' = rev, 'Поставка' = pr)}
		for (i in (1:lenght(goods)) {
			line <- cbind(line, goods[i])
}
	 else { 
		line <- data.frame('День' = rev, 'Продажа' = pr)
		line <- cbind(line, goods[i])
	}
for (i in 1:days){
	line[i,1] <- i
	for (j in (1:lenght(goods)) {
			line[i,j] <- sample(m:M, 1)
	}
}
write.table(line ,file=paste(name,type,sep=''), col.names=TRUE,row.names=FALSE,sep=' ',dec=',')
}
