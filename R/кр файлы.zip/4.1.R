
setwd("/Users/violettakorotenko/Desktop/Korotenkocompany/")

tort<-function(input, sale){       # функция, позволяющая продажам не превышать поставки 
  for (i in 1:7){
    if (input[i] < sale[i]){
      sale[i] <- sample(35:input[i], size = 1)
    }
  }
  return(sale)     
}

generate.supply.sale <-        #функция, генирирующая файлы in.txt и out.txt
  function(name, type, min_gener, max_gener, flag) {
    setwd("/Users/violettakorotenko/Desktop/Korotenkocompany/")
    a <- c(1:7)
    x <- as.integer(sample(min_gener:max_gener, size = 7))
    y <- as.integer(sample(min_gener:max_gener, size = 7))
    if (type == 1) {
      in1 <- data.frame("День" = a, "Поставка" = x)
      write.table(in1, file = name, row.names = FALSE, sep = "     ")
    }
    else if (type == 2) {
      out <- data.frame("День" = a, "Продажа" = y)
      write.table(out,
                  file = name,
                  row.names = FALSE,
                  sep = "     "
      )
    }
  }

#дальше будет вызов функций для того,  чтобы в папках Магазин1-Магазин 10 появились файлы in.txt и out.txt(продажа и поставки ).Можно было вызвать с помощью цикла, но я захотела так

generate.supply.sale(
  name = "магазин1/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин1/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("/Users/violettakorotenko/Desktop/Korotenkocompany/магазин1")
in1 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out1 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out1$Продажа <- tort(in1$Поставка, out1$Продажа)
write.table(out1, file = "out.txt",row.names = FALSE,
            sep = "     ")
generate.supply.sale(
  name = "магазин2/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин2/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("/Users/violettakorotenko/Desktop/Korotenkocompany/магазин2")
in2 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out2 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out2$Продажа <- tort(in2$Поставка, out2$Продажа)
write.table(out2, file = "out.txt",row.names = FALSE,
            sep = "     ")

generate.supply.sale(
  name = "магазин3/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин3/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("/Users/violettakorotenko/Desktop/Korotenkocompany/магазин3")
in3 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out3 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out3$Продажа <- tort(in3$Поставка, out3$Продажа)
write.table(out3, file = "out.txt",row.names = FALSE,
            sep = "     ")

generate.supply.sale(
  name = "магазин4/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин4/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("/Users/violettakorotenko/Desktop/Korotenkocompany/магазин4")
in4 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out4 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out4$Продажа <- tort(in4$Поставка, out4$Продажа)
write.table(out4, file = "out.txt",row.names = FALSE,
            sep = "     ")

generate.supply.sale(
  name = "магазин5/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин5/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("/Users/violettakorotenko/Desktop/Korotenkocompany/магазин5")
in5 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out5 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out5$Продажа <- tort(in5$Поставка, out5$Продажа)
write.table(out5, file = "out.txt",row.names = FALSE,
            sep = "     ")

generate.supply.sale(
  name = "магазин6/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин6/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("/Users/violettakorotenko/Desktop/Korotenkocompany/магазин6")
in6 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out6 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out6$Продажа <- tort(in6$Поставка, out6$Продажа)
write.table(out6, file = "out.txt",row.names = FALSE,
            sep = "     ")

generate.supply.sale(
  name = "магазин7/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин7/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("/Users/violettakorotenko/Desktop/Korotenkocompany/магазин7")
in7 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out7 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out7$Продажа <- tort(in7$Поставка, out7$Продажа)
write.table(out7, file = "out.txt",row.names = FALSE,
            sep = "     ")

generate.supply.sale(
  name = "магазин8/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин8/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("/Users/violettakorotenko/Desktop/Korotenkocompany/магазин8")
in8 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out8 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out8$Продажа <- tort(in8$Поставка, out8$Продажа)
write.table(out8, file = "out.txt",row.names = FALSE,
            sep = "     ")

generate.supply.sale(
  name = "магазин9/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин9/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("/Users/violettakorotenko/Desktop/Korotenkocompany/магазин9")
in9 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out9 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out9$Продажа <- tort(in9$Поставка, out9$Продажа)
write.table(out9, file = "out.txt",row.names = FALSE,
            sep = "     ")

generate.supply.sale(
  name = "магазин10/in.txt",
  type = 1,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
generate.supply.sale(
  name = "магазин10/out.txt",
  type = 2,
  min_gener = 35,
  max_gener = 55,
  flag = TRUE
)
setwd("/Users/violettakorotenko/Desktop/Korotenkocompany/магазин10")
in10 <- read.table("in.txt", head = TRUE, encoding = "UTF-8")
out10 <- read.table("out.txt", head = TRUE, encoding = "UTF-8")
out10$Продажа <- tort(in10$Поставка, out10$Продажа)
write.table(out10, file = "out.txt",row.names = FALSE,
            sep = "     ")


