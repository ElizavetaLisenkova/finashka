{
  n = scan(nmax = 1)
  print(sum(c(1:n)))
}
