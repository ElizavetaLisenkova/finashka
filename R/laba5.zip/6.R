{
  ab <- scan(nmax = 2)
  ab <- sort(ab, decreasing = T)
  vec <- c(c(ab[1]:ab[2])[c(ab[1]:ab[2]) %% 3 == 0])
  print(vec)
}