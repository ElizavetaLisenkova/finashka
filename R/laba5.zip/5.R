{
  n <- scan(nmax = 1)
  if (round(n) == n) {
    print("��")
  }
  else {
    print('���')
  }
}