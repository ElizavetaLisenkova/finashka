{
  v <- vector()
  for (i in (1:8)) {
    v <- append(v, scan(nmax = 1))
  }
  v <- sort(v, decreasing = T)
  v
}
