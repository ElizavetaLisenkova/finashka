{
  word <- "def"
  
  while (identical(toupper(word), "СТОП") == F)
  {
    word <- scan(what = character(), n = 1)
  }
}
