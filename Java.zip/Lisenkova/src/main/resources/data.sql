INSERT  INTO news (title, author, creation_date, update_date, text, category)
VALUES ('title1', 'author1', '01-01-2020', '03-01-2020', 'texttexttext', 'category1'),
('title2', 'author2', '01-02-2020', '03-02-2020', 'texttexttext2', 'category2'),
('title3', 'author3', '01-03-2020', '03-03-2020', 'texttexttext3', 'category3');

