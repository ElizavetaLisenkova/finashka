package com.example.Lisenkova;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LisenkovaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LisenkovaApplication.class, args);
	}

}
