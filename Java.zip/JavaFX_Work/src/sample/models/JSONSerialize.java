package sample.models;

public interface JSONSerialize {
    String toJson();
}
