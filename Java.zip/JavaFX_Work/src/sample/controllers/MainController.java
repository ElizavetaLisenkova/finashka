package sample.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class MainController {
    // Контроллер для главного меню приложения
    @FXML
    private Button fileButton;

    @FXML
    private Button editButton;

    @FXML
    private Button helpButton;

    // Проставить id для всех элементов внутри SceneBuilder
}
