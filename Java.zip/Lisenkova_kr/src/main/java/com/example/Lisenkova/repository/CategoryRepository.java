package com.example.Lisenkova.repository;

import com.example.Lisenkova.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category,Long> {
}
