package com.example.rest_pi192;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestPi192ApplicationTests {

	@Test
	void contextLoads() {
	}

}
