import math 
import time
import datetime
from tkinter import *

root = Tk()
canvas = Canvas(root, width = 500, height = 550, bg="black") #инициализация холста 500х500
canvas.pack()#размещаем холст в нашем окне


#выводим точку - центр циферблата, чтобы было куда стрелки крепить
canvas.create_text(250, 225, text = '.', font = ("Arial", 62))


i = 0
while i < 12:  #цикл вывода цифр часов
    i += 1
    canvas.create_text(250 + 225 * math.cos(-i * 30 * math.pi/180 + math.pi/2),
                       250 - 225 * math.sin(-30 * i * math.pi/180 + math.pi/2),
                       text = i, font = ('Arial' ,16), fill="white")

date1 = datetime.date.today()
i = 950  # счетчик цикла  и координата х для вывода текста бегущей строки
while 1:  # основной бесконечный цикл
    time_now = time.localtime()  # получаем текущее время в виде
    # time.struct_time(tm_year=2016, tm_mon=3, tm_mday=27, tm_hour=22,
    # tm_min=23, tm_sec=35, tm_wday=6, tm_yday=87, tm_isdst=0)
    time_sec = int(time.strftime("%S", time_now))  # получаем секунды из переменной time_now
    time_hour = int(time.strftime("%I", time_now))  # получаем часы из переменной time_now
    time_min = int(time.strftime("%M", time_now))  # получаем минуты из переменной time_now
    sec_angle = 6 * time_sec  # угол отклонения секундной стрелки за 1 секунду
    min_angle = time_min * 6 + time_sec * 0.1  # угол отклонения минутной стрелки за 1 секунду
    # угол отклонения часовой стрелки за 1 секунду
    hour_angle = time_hour * 30 + time_min * 60 * (30 / 3600)

    # рисуем минутную стрелку
    line_min = canvas.create_line(250,
                                  250,
                                  250 - 140 * math.cos(min_angle * math.pi / 180 + math.pi / 2),
                                  250 - 140 * math.sin(min_angle * math.pi / 180 + math.pi / 2),
                                  width=6, fill='pink')
    # рисуем часовую стрелку
    line_hour = canvas.create_line(250,
                                   250,
                                   250 - 90 * math.cos(hour_angle * math.pi / 180 + math.pi / 2),
                                   250 - 90 * math.sin(hour_angle * math.pi / 180 + math.pi / 2),
                                   width=6, fill='purple')
    # рисуем секундную стрелку
    line_sec = canvas.create_line(250,
                                  250,
                                  250 - 180 * math.cos(sec_angle * math.pi / 180 + math.pi / 2),
                                  250 - 180 * math.sin(sec_angle * math.pi / 180 + math.pi / 2),
                                  width=6, fill='green')
    # Задаем бегущую строку
    text_bottom = canvas.create_text(i, 525,
                                     text='Сегодняшняя дата:  ' +
                                          f'{date1}', font=('Arial', 16), fill="white")
    i = i - 0.5
    if i == -600:
        i = 950
    root.update()  # обновляем экран/холст
    canvas.delete(line_sec)  # удаляем секундную стрелку
    canvas.delete(line_min)  # удаляем минутную стрелку
    canvas.delete(line_hour)  # удаляем часовую стрелку
    canvas.delete(text_bottom)  # удаляем строку внизу

root.mainloop  # создаем постоянный цикл