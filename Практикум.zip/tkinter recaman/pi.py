import math
from tkinter import Tk, Canvas, ARC

def numbers(n) :
    arr = [3]
    x = math.pi%1
    i = 0
    while i<n:
        x = 1/x
        arr.append(x//1)
        x = x%1
        i+=1
    return arr


root = Tk()
canvas = Canvas(root, width = 1000, height = 1000, bg = "black")
canvas.pack()

def arc1(arr, i):
    canvas.create_arc(arr[i], 500+(arr[i+1]-arr[i])/2, arr[i+1], 500-(arr[i+1]-arr[i])/2, start = 0, extent=-180, style=ARC, outline='white', width=0.3)

def arc2(arr, i):
    canvas.create_arc(arr[i], 500+(arr[i+1]-arr[i])/2, arr[i+1], 500-(arr[i+1]-arr[i])/2, start = 180, extent=-180, style=ARC, outline='white', width=0.3)
 

arr = numbers(1500)

for i in range(0, len(arr)-1):
    if i%2 == 0:
        root.after(4, arc1(arr, i))
        root.update() 
    else:
        root.after(4, arc2(arr, i))
        root.update() 


root.mainloop()
