# from math import *
from tkinter import Tk, Canvas, ARC

def numbers(n) :
    arr = []
    for i in range(0, n, 50):
        arr.append(i)
    print(arr)
    return arr


root = Tk()
canvas = Canvas(root, width = 1000, height = 1000, bg = "black")
canvas.pack()

def arc1(arr, i):
    canvas.create_arc(arr[i], 500+(arr[i+1]-arr[i])/2, arr[i+1], 500-(arr[i+1]-arr[i])/2, start = 0, extent=-180, style=ARC, outline='white', width=0.3)

def arc2(arr, i):
    canvas.create_arc(arr[i], 500+(arr[i+1]-arr[i])/2, arr[i+1], 500-(arr[i+1]-arr[i])/2, start = 180, extent=-180, style=ARC, outline='white', width=0.3)
 

arr = numbers(1000)
for i in range(0, len(arr)-1):

    if i%2 == 0:
        root.after(20, arc1(arr, i))
        root.update() 
    else:
        root.after(20, arc2(arr, i))
        root.update() 


root.mainloop()
