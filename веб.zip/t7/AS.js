AS = [{
	"Category": "Психоневрологический интернат",
	"CommonName": "Психоневрологический интернат № 26",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 26 Департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ГБУ ПНИ № 26",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 26 Департамента труда и социальной защиты населения города Москвы",
		"INN": "7720152070",
		"KPP": "772001001",
		"OGRN": "1037739576962",
		"LegalAddress": "111538, ГОРОД МОСКВА, УЛИЦА КОСИНСКАЯ, 8",
		"ChiefName": "Раковская Людмила Александровна",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(495) 375-43-31"
		}]
	}],
	"ObjectAddress": [{
		"AdmArea": "Восточный административный округ",
		"District": "район Вешняки",
		"PostalCode": "111538",
		"Address": "город Москва, Косинская улица, дом 8",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "полностью",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": [{
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "информационные указатели",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "тактильная полоса перед входной лестницей",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "контрастная маркировка ступеней",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "платформа подъемная (мобильный лестничный подъемник)",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "территория объекта",
				"Element_mgn": "указатели направления движения",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона рядом с унитазом",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона у раковины для кресла-коляски",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "частично",
				"available_index": "есть"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(495) 375-43-31"
	}],
	"ChiefName": "Раковская Людмила Александровна",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "среда",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "круглосуточно"
	}],
	"ClarificationWorkingHours": "график работы администрации: пн-чт: 09:00-17:45; пт: 09:00-16:30",
	"WebSite": "pni26.ru",
	"global_id": 641991308,
	"geoData": {
		"coordinates": [
			[37.836165750243, 55.7266517006038]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [37.836165750243, 55.7266517006038],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "Психоневрологический интернат № 25",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 25 Департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ГБУ ПНИ № 25",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 25 Департамента труда и социальной защиты населения города Москвы.",
		"INN": "7711046615",
		"KPP": "774301001",
		"OGRN": "1037739513910",
		"LegalAddress": "125412, ГОРОД МОСКВА, УЛИЦА ТАЛДОМСКАЯ, 6",
		"ChiefName": "Горпинченко Михаил Михайлович",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(499) 487-72-45"
		}]
	}],
	"ObjectAddress": [{
		"AdmArea": "Северный административный округ",
		"District": "район Западное Дегунино",
		"PostalCode": "125412",
		"Address": "город Москва, Талдомская улица, дом 6",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "полностью",
			"available_o": "полностью",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": [{
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "платформа подъемная (мобильный лестничный подъемник)",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "места для инвалидов по слуху в зале",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "информационные указатели",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "контрастная маркировка ступеней",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "территория объекта",
				"Element_mgn": "указатели направления движения",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "места для инвалидов-колясочников в зале",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "есть"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(499) 487-72-45"
	}],
	"ChiefName": "Горпинченко Михаил Михайлович",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "среда",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "круглосуточно"
	}],
	"ClarificationWorkingHours": "администрация пн-пт: 09.00 – 18.00",
	"WebSite": "pni25.ru",
	"global_id": 641991365,
	"geoData": {
		"coordinates": [
			[37.5256771068932, 55.8734745023725]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [37.5256771068932, 55.8734745023725],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "Психоневрологический интернат № 30",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 30 Департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ГБУ ПНИ № 30",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат №30 Департамента труда и социальной защиты населения города Москвы",
		"INN": "7726033231",
		"KPP": "772601001",
		"OGRN": "1037739021308",
		"LegalAddress": "117525, ГОРОД МОСКВА, УЛИЦА ДНЕПРОПЕТРОВСКАЯ, ДОМ 14",
		"ChiefName": "Лебединская Ольга Ивановна",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(495) 640-73-87"
		}]
	}],
	"ObjectAddress": [{
		"AdmArea": "Южный административный округ",
		"District": "район Чертаново Центральное",
		"PostalCode": "117525",
		"Address": "Российская Федерация, город Москва, внутригородская территория муниципальный округ Чертаново Центральное, Днепропетровская улица, дом 14, строение 1",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "полностью",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": [{
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "территория объекта",
				"Element_mgn": "указатели направления движения",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "платформа подъемная (мобильный лестничный подъемник)",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона рядом с унитазом",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "контрастная маркировка ступеней",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "информационные указатели",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона у раковины для кресла-коляски",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "тактильная полоса перед входной лестницей",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(495) 640-73-87"
	}],
	"ChiefName": "Лебединская Ольга Ивановна",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "среда",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "круглосуточно"
	}],
	"ClarificationWorkingHours": "администрация: пн-пт 09.00 – 17.30",
	"WebSite": "pni30.ru",
	"global_id": 641991373,
	"geoData": {
		"coordinates": [
			[37.5762531533669, 55.6205294003131]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [37.5762531533669, 55.6205294003131],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "Психоневрологический интернат № 23",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 23 Департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ГБУ ПНИ № 23",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 23 Департамента труда и социальной защиты населения города Москвы",
		"INN": "7716015258",
		"KPP": "771601001",
		"OGRN": "1027739566360",
		"LegalAddress": "129347, ГОРОД МОСКВА, УЛИЦА РОТЕРТА, 6",
		"ChiefName": "Литвинова Мария Валерьевна",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(499) 182-03-92"
		}]
	}],
	"ObjectAddress": [{
		"AdmArea": "Северо-Восточный административный округ",
		"District": "Ярославский район",
		"PostalCode": "129347",
		"Address": "город Москва, улица Ротерта, дом 6",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "частично",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": [{
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "места для инвалидов-колясочников в зале",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "информационные указатели",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "платформа подъемная (мобильный лестничный подъемник)",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "территория объекта",
				"Element_mgn": "указатели направления движения",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "места для инвалидов по слуху в зале",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона у раковины для кресла-коляски",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "контрастная маркировка ступеней",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона рядом с унитазом",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(499) 182-03-92"
	}],
	"ChiefName": "Литвинова Мария Валерьевна",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "среда",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "круглосуточно"
	}],
	"ClarificationWorkingHours": "",
	"WebSite": "pni23.ru",
	"global_id": 641991457,
	"geoData": {
		"coordinates": [
			[37.7301707070423, 55.8761765039324]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [37.7301707070423, 55.8761765039324],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "Психоневрологический интернат № 11",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 11 Департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ГБУ города Москвы ПНИ № 11 ДТиСЗН города Москвы",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 11 Департамента труда и социальной защиты населения города Москвы",
		"INN": "7723585749",
		"KPP": "772101001",
		"OGRN": "5067746766665",
		"LegalAddress": "109559, ГОРОД МОСКВА, УЛИЦА СТАВРОПОЛЬСКАЯ, 37, 1-7",
		"ChiefName": "Суродин Виктор Николаевич",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(495) 350-39-38"
		}]
	}],
	"ObjectAddress": [{
		"AdmArea": "Юго-Восточный административный округ",
		"District": "район Люблино",
		"PostalCode": "109559",
		"Address": "город Москва, Ставропольская улица, дом 37, корпус 1",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "полностью",
			"available_o": "частично",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": [{
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "территория объекта",
				"Element_mgn": "указатели направления движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона у раковины для кресла-коляски",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона рядом с унитазом",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "тактильная полоса перед входной лестницей",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "контрастная маркировка ступеней",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "места для инвалидов-колясочников в зале",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "места для инвалидов по слуху в зале",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(495) 350-01-58"
	}, {
		"PublicPhone": "(495) 350-39-38"
	}],
	"ChiefName": "Суродин Виктор Николаевич",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "09:00-18:00"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "09:00-18:00"
	}, {
		"DayWeek": "среда",
		"WorkHours": "09:00-18:00"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "09:00-18:00"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "09:00-16:45"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "выходной"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "выходной"
	}],
	"ClarificationWorkingHours": "обед: 13:00-13:45",
	"WebSite": "пни11.рф",
	"global_id": 641991500,
	"geoData": {
		"coordinates": [
			[37.7730299343669, 55.684682000794]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [37.7730299343669, 55.684682000794],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "Психоневрологический интернат № 16",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 16 Департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ГБУ ПНИ № 16",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 16 Департамента труда и социальной защиты населения города Москвы",
		"INN": "7725052136",
		"KPP": "772501001",
		"OGRN": "1027700325828",
		"LegalAddress": "115487, ГОРОД МОСКВА, УЛИЦА САДОВНИКИ, ДОМ 15",
		"ChiefName": "Кожекин Игорь Геннадьевич",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(499) 612-24-97"
		}]
	}],
	"ObjectAddress": [{
		"AdmArea": "Южный административный округ",
		"District": "район Нагатино-Садовники",
		"PostalCode": "115487",
		"Address": "Российская Федерация, город Москва, внутригородская территория муниципальный округ Нагатино-Садовники, улица Садовники, дом 15",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "частично",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": [{
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "недоступно",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "платформа подъемная (мобильный лестничный подъемник)",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "платформа подъемная (мобильный лестничный подъемник)",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "тактильная полоса перед входной лестницей",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "территория объекта",
				"Element_mgn": "указатели направления движения",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "информационные указатели",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "недоступно",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "места для инвалидов по слуху в зале",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "недоступно",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "контрастная маркировка ступеней",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "недоступно",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "места для инвалидов-колясочников в зале",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "обслуживание через окно/прилавок",
				"available_degree": "частично",
				"available_index": "соответствует"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(499) 612-24-97"
	}, {
		"PublicPhone": "(499) 612-00-47"
	}],
	"ChiefName": "Кожекин Игорь Геннадьевич",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "среда",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "круглосуточно"
	}],
	"ClarificationWorkingHours": "администрация пн-чт: 8:30 – 17:15 пт: 8:30 – 16:00",
	"WebSite": "www.пни16.рф",
	"global_id": 641991624,
	"geoData": {
		"coordinates": [
			[37.6557817035097, 55.6708860672922]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [37.6557817035097, 55.6708860672922],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "Психоневрологический интернат № 20",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 20 Департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ГБУ ПНИ № 20",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 20 Департамента труда и социальной защиты населения города Москвы",
		"INN": "7728021231",
		"KPP": "772801001",
		"OGRN": "1037739674378",
		"LegalAddress": "119421, ГОРОД МОСКВА, УЛИЦА ОБРУЧЕВА, ДОМ 28, КОРПУС 4",
		"ChiefName": "Бесштанько Андрей Владимирович",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(495) 936-57-31"
		}]
	}],
	"ObjectAddress": [{
		"AdmArea": "Юго-Западный административный округ",
		"District": "Обручевский район",
		"PostalCode": "119421",
		"Address": "город Москва, улица Обручева, дом 28, корпус 4",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "частично",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": [{
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона рядом с унитазом",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "территория объекта",
				"Element_mgn": "указатели направления движения",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "информационные указатели",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "места для инвалидов-колясочников в зале",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона у раковины для кресла-коляски",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "тактильная полоса перед входной лестницей",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "контрастная маркировка ступеней",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "места для инвалидов по слуху в зале",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "платформа подъемная (мобильный лестничный подъемник)",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(495) 936-57-31"
	}],
	"ChiefName": "Бесштанько Андрей Владимирович",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "среда",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "круглосуточно"
	}],
	"ClarificationWorkingHours": "администрация пн-пт: 09.00 – 17.30",
	"WebSite": "www.pni20.ru",
	"global_id": 641991625,
	"geoData": {
		"coordinates": [
			[37.514337976823, 55.6555871848077]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [37.514337976823, 55.6555871848077],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "Психоневрологический интернат № 4",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 4 Департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ГБУ ПНИ № 4",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 4 Департамента труда и социальной защиты населения города Москвы",
		"INN": "7731114221",
		"KPP": "773101001",
		"OGRN": "1037700107158",
		"LegalAddress": "121433, ГОРОД МОСКВА, УЛИЦА ПОЛОСУХИНА, 3",
		"ChiefName": "Кипкеева Светлана Азретовна",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(499) 144-92-41"
		}, {
			"ChiefPhone": "(499) 144-26-83"
		}]
	}],
	"ObjectAddress": [{
		"AdmArea": "Западный административный округ",
		"District": "район Фили-Давыдково",
		"PostalCode": "121433",
		"Address": "город Москва, улица Полосухина, дом 3, корпус 1",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "полностью",
			"available_z": "частично",
			"available_s": "полностью",
			"available_element": [{
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона рядом с унитазом",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "территория объекта",
				"Element_mgn": "указатели направления движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "платформа подъемная (мобильный лестничный подъемник)",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "тактильная полоса перед входной лестницей",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона у раковины для кресла-коляски",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "места для инвалидов-колясочников в зале",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "контрастная маркировка ступеней",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "частично",
				"available_index": "нет"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(499) 144-26-83"
	}, {
		"PublicPhone": "(499) 144-92-41"
	}],
	"ChiefName": "Кипкеева Светлана Азретовна",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "среда",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "круглосуточно"
	}],
	"ClarificationWorkingHours": "График посещения проживающих в ГБУ ПНИ № 4:\nежедневно 9.30 – 20.00; администрация: пн-чт: 08.00 – 16.45; пт: 08.00 – 15.30",
	"WebSite": "pni4.ru",
	"global_id": 641991636,
	"geoData": {
		"coordinates": [
			[37.458297212125, 55.7361599180168]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [37.458297212125, 55.7361599180168],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "Психоневрологический интернат № 5",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 5 Департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ГБУ ПНИ № 5",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 5 Департамента труда и социальной защиты населения города Москвы",
		"INN": "5003009280",
		"KPP": "775101001",
		"OGRN": "1035000910724",
		"LegalAddress": "108821, ГОРОД МОСКВА, ПОСЕЛЕНИЕ ФИЛИМОНКОВСКОЕ, ПОСЕЛОК ФИЛИМОНКИ, ТЕРРИТОРИЯ ПНИ №5",
		"ChiefName": "Лопаткина Наталья Владимировна",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(495) 436-64-69"
		}]
	}],
	"ObjectAddress": [{
		"AdmArea": "Новомосковский административный округ",
		"District": "поселение Филимонковское",
		"PostalCode": "108821",
		"Address": "город Москва, поселение Филимонковское, посёлок Филимонки, дом 1Б/Н",
		"SocialServices": ["Обогрев и санитарная помощь", "Обеспечение одеждой, обувью и предметами первой необходимости", "Помощь в оформлении и восстановлении документов", "Временное проживание в учреждении", "Юридическая помощь"],
		"Availability": [{
			"available_k": "частично",
			"available_o": "частично",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": [{
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "территория объекта",
				"Element_mgn": "указатели направления движения",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "платформа подъемная (мобильный лестничный подъемник)",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "недоступно",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "недоступно",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "недоступно",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "недоступно",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "контрастная маркировка ступеней",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "места для инвалидов-колясочников в зале",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "места для инвалидов по слуху в зале",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "информационные указатели",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "тактильная полоса перед входной лестницей",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(495) 436-64-69"
	}],
	"ChiefName": "Лопаткина Наталья Владимировна",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "08:30-17:30"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "08:30-17:30"
	}, {
		"DayWeek": "среда",
		"WorkHours": "08:30-17:30"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "08:30-17:30"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "08:30-16:15"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "выходной"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "выходной"
	}],
	"ClarificationWorkingHours": "Обед: с 12-30 до 13-15\nЧасы приема вновь поступающих:\nПонедельник - пятница:\nначало приема 09:00;\nокончание приема 16:00;\nобеденный перерыв с 12:30 до 13:15\nЧасы посещений:\nЕжедневно с 09:00 до 18:00",
	"WebSite": "pni5.ru",
	"global_id": 641991642,
	"geoData": {
		"coordinates": [
			[37.3442795000495, 55.5600981947062]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [37.3442795000495, 55.5600981947062],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "Психоневрологический интернат № 12",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 12 Департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ГБУ ПНИ № 12",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 12 Департамента труда и социальной защиты населения города Москвы",
		"INN": "7719019363",
		"KPP": "771901001",
		"OGRN": "1037700064720",
		"LegalAddress": "105215, ГОРОД МОСКВА, УЛИЦА 9-Я ПАРКОВАЯ, 53",
		"ChiefName": "Шестакова Яна Сергеевна",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(499) 164-89-42"
		}]
	}],
	"ObjectAddress": [{
		"AdmArea": "Восточный административный округ",
		"District": "район Северное Измайлово",
		"PostalCode": "102215",
		"Address": "город Москва, 9-я Парковая улица, дом 53",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "полностью",
			"available_o": "полностью",
			"available_z": "частично",
			"available_s": "полностью",
			"available_element": [{
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона рядом с унитазом",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "территория объекта",
				"Element_mgn": "указатели направления движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "тактильная полоса перед входной лестницей",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона у раковины для кресла-коляски",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "контрастная маркировка ступеней",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "полностью",
				"available_index": "есть"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(499) 164-89-42"
	}],
	"ChiefName": "Шестакова Яна Сергеевна",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "среда",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "круглосуточно"
	}],
	"ClarificationWorkingHours": "администрация пн-чт: 09.00 – 17.45; пт: 9.00 - 16.30",
	"WebSite": "пни12.рф",
	"global_id": 641991685,
	"geoData": {
		"coordinates": [
			[37.7975908425138, 55.8072365710085]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [37.7975908425138, 55.8072365710085],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "ПНИ № 18",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 18 департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ГБУ ПНИ № 18",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 18 Департамента труда и социальной защиты населения города Москвы",
		"INN": "7727051628",
		"KPP": "772701001",
		"OGRN": "1037700180869",
		"LegalAddress": "117303, ГОРОД МОСКВА, УЛИЦА КАХОВКА, 8",
		"ChiefName": "Горчакова Лариса Ивановна",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(499) 121-92-10"
		}]
	}],
	"ObjectAddress": [{
		"AdmArea": "Юго-Западный административный округ",
		"District": "район Зюзино",
		"PostalCode": "117303",
		"Address": "город Москва, улица Каховка, дом 8, корпус 1",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "полностью",
			"available_o": "полностью",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": [{
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "места для инвалидов по слуху в зале",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "территория объекта",
				"Element_mgn": "указатели направления движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона рядом с унитазом",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона у раковины для кресла-коляски",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "тактильная полоса перед входной лестницей",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "контрастная маркировка ступеней",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "платформа подъемная (мобильный лестничный подъемник)",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(499) 121-92-10"
	}],
	"ChiefName": "Горчакова Лариса Ивановна",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "среда",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "круглосуточно"
	}],
	"ClarificationWorkingHours": "График работы: понедельник-четверг с 09:00 до 17:45, пятница с 09:00 до 16:30, обед с 13:00 до 14:00\n\nДни посещений: среда с 15:00 до 18:00 , суббота-воскресенье с 10:00 до 13:00\n",
	"WebSite": "pni-18.ru",
	"global_id": 641991737,
	"geoData": {
		"coordinates": [
			[37.5835840283848, 55.6540779467645]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [37.5835840283848, 55.6540779467645],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "Психоневрологический интернат № 22",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 22 Департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ГБУ города Москвы ПНИ № 22 ДТСЗН города Москвы",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 22 Департамента труда и социальной защиты населения города Москвы",
		"INN": "7718059902",
		"KPP": "771801001",
		"OGRN": "1037718028226",
		"LegalAddress": "107150, ГОРОД МОСКВА, УЛИЦА ЛОСИНООСТРОВСКАЯ, ДОМ 27",
		"ChiefName": "Ключев Антон Александрович",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(499) 160-02-86"
		}]
	}],
	"ObjectAddress": [{
		"AdmArea": "Восточный административный округ",
		"District": "район Метрогородок",
		"PostalCode": "107150",
		"Address": "город Москва, Лосиноостровская улица, дом 27, строение 1",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "частично",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": [{
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "места для инвалидов-колясочников в зале",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "недоступно",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "платформа подъемная (мобильный лестничный подъемник)",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "территория объекта",
				"Element_mgn": "указатели направления движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "места для инвалидов по слуху в зале",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "контрастная маркировка ступеней",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "недоступно",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "частично",
				"available_index": "нет"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(499) 160-16-68"
	}],
	"ChiefName": "Ключев Антон Александрович",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "среда",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "круглосуточно"
	}],
	"ClarificationWorkingHours": "администрация пн-пт: 08.00 – 17.00",
	"WebSite": "www.pni22.ru",
	"global_id": 641991802,
	"geoData": {
		"coordinates": [
			[37.7131764075401, 55.8272677486869]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [37.7131764075401, 55.8272677486869],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "Психоневрологический интернат № 34",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 34 Департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ПНИ № 34",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 34 Департамента труда и социальной защиты населения города Москвы.",
		"INN": "7724040160",
		"KPP": "772401001",
		"OGRN": "1027700211505",
		"LegalAddress": "115522, ГОРОД МОСКВА, УЛИЦА МОСКВОРЕЧЬЕ, 7",
		"ChiefName": "Шуляк Юрий Афанасьевич",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(499) 324-53-89"
		}]
	}],
	"ObjectAddress": [{
		"AdmArea": "Южный административный округ",
		"District": "район Москворечье-Сабурово",
		"PostalCode": "115522",
		"Address": "город Москва, улица Москворечье, дом 7",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "частично",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": [{
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "недоступно",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "контрастная маркировка ступеней",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "территория объекта",
				"Element_mgn": "указатели направления движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "недоступно",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "тактильная полоса перед входной лестницей",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "частично",
				"available_index": "нет"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(499) 324-53-89"
	}],
	"ChiefName": "Шуляк Юрий Афанасьевич",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "08:30-17:00"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "08:30-17:00"
	}, {
		"DayWeek": "среда",
		"WorkHours": "08:30-17:00"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "08:30-17:00"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "08:30-17:00"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "выходной"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "выходной"
	}],
	"ClarificationWorkingHours": "График посещений:\nпонедельник - воскресение: с 11-00 до 13-00, с 16-00 до 19-00.",
	"WebSite": "pni34.ru",
	"global_id": 830697765,
	"geoData": {
		"coordinates": [
			[37.6456930007353, 55.6521262592663]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [37.6456930007353, 55.6521262592663],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "Геронтопсихиатрический центр милосердия",
	"FullName": "Государственное бюджетное учреждение города Москвы Геронтопсихиатрический центр милосердия",
	"ShortName": "ГБУ г. Москвы Геронтопсихиатрический центр милосердия",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Геронтопсихиатрический центр милосердия Департамента социальной защиты населения города Москвы",
		"INN": "7737017418",
		"KPP": "772401001",
		"OGRN": "1027739371472",
		"LegalAddress": "115569, ГОРОД МОСКВА, ПРОЕЗД ШИПИЛОВСКИЙ, 31",
		"ChiefName": "Зубков Евгений Александрович",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(495) 391-93-62"
		}]
	}],
	"ObjectAddress": [{
		"AdmArea": "Южный административный округ",
		"District": "район Орехово-Борисово Северное",
		"PostalCode": "115569",
		"Address": "город Москва, Шипиловский проезд, дом 31, строение 5",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "частично",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": []
		}]
	}, {
		"AdmArea": "Южный административный округ",
		"District": "район Орехово-Борисово Северное",
		"PostalCode": "115569",
		"Address": "город Москва, Шипиловский проезд, дом 31, строение 3",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "частично",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": []
		}]
	}, {
		"AdmArea": "Южный административный округ",
		"District": "район Орехово-Борисово Северное",
		"PostalCode": "115569",
		"Address": "город Москва, Шипиловский проезд, дом 31",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "частично",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": [{
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "информационные указатели",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "территория объекта",
				"Element_mgn": "указатели направления движения",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона рядом с унитазом",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона у раковины для кресла-коляски",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "контрастная маркировка ступеней",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "платформа подъемная (мобильный лестничный подъемник)",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "тактильная полоса перед входной лестницей",
				"available_degree": "частично",
				"available_index": "нет"
			}]
		}]
	}, {
		"AdmArea": "Южный административный округ",
		"District": "район Орехово-Борисово Северное",
		"PostalCode": "115569",
		"Address": "город Москва, Шипиловский проезд, дом 31, строение 4",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "частично",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": []
		}]
	}, {
		"AdmArea": "Южный административный округ",
		"District": "район Орехово-Борисово Северное",
		"PostalCode": "115569",
		"Address": "город Москва, Шипиловский проезд, дом 31, строение 7",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "частично",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": [{
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "тактильная полоса перед входной лестницей",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "информационные указатели",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона рядом с унитазом",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона у раковины для кресла-коляски",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}]
		}]
	}, {
		"AdmArea": "Южный административный округ",
		"District": "район Орехово-Борисово Северное",
		"PostalCode": "115569",
		"Address": "город Москва, Шипиловский проезд, дом 31, строение 2",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "частично",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": []
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(495) 391-27-22"
	}],
	"ChiefName": "Зубков Евгений Александрович",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "среда",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "круглосуточно"
	}],
	"ClarificationWorkingHours": "Режим работы администрации:  понедельник 09:00-18:00; вторник 09:00-18:00; среда 09:00-18:00; четверг 09:00-18:00; пятница 09:00-18:00",
	"WebSite": "www.gbugcm.ru",
	"global_id": 969662537,
	"geoData": {
		"coordinates": [
			[37.69659551235, 55.6162447297343],
			[37.6968946751589, 55.6155135947922],
			[37.6964338261434, 55.6155569213247],
			[37.6962175643179, 55.614874889319],
			[37.6974701522245, 55.6162948327341],
			[37.6969167165574, 55.6151900585363]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [37.6968946751589, 55.6155135947922],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "Психоневрологический интернат № 2",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 2 Департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ГБУ ПНИ № 2",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 2 Департамента труда и социальной защиты населения города Москвы.",
		"INN": "5077000796",
		"KPP": "507701001",
		"OGRN": "1025007772239",
		"LegalAddress": "142200, ОБЛАСТЬ МОСКОВСКАЯ, ГОРОД СЕРПУХОВ, МЕСТЕЧКО ДАНКИ",
		"ChiefName": "Зиновьева Нина Алексеевна",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(496) 770-71-38"
		}]
	}],
	"ObjectAddress": [{
		"PostalCode": "142200",
		"Address": "ОБЛАСТЬ МОСКОВСКАЯ, РАЙОН СЕРПУХОВСКИЙ, МЕСТЕЧКО ДАНКИ",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "частично",
			"available_z": "полностью",
			"available_s": "полностью",
			"available_element": [{
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона рядом с унитазом",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона у раковины для кресла-коляски",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "тактильная полоса перед входной лестницей",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "полностью",
				"available_index": "есть"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(496) 770-71-38"
	}, {
		"PublicPhone": "(499) 755-56-47"
	}],
	"ChiefName": "Зиновьева Нина Алексеевна",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "08:00-15:45"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "08:00-15:45"
	}, {
		"DayWeek": "среда",
		"WorkHours": "08:00-15:45"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "08:00-15:45"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "08:00-15:45"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "выходной"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "выходной"
	}],
	"ClarificationWorkingHours": "Перерыв 12:00 - 12:30 \n\nГрафик приема граждан директором: \nкаждый понедельник с 15:00 до 17:00\n\nРежим работы учреждения: круглосуточно \n\n\n",
	"WebSite": "pni2.ru",
	"global_id": 1019279743,
	"geoData": {
		"coordinates": [
			[37.567184853819, 54.913849947504]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [37.567184853819, 54.913849947504],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "Психоневрологический интернат № 10",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 10 Департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ГБУ ПНИ № 10",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 10 Департамента труда и социальной защиты населения города Москвы.",
		"INN": "5003009314",
		"KPP": "500301001",
		"OGRN": "1035000910141",
		"LegalAddress": "142700, ОБЛАСТЬ МОСКОВСКАЯ, РАЙОН ЛЕНИНСКИЙ, ГОРОД ВИДНОЕ, УЛИЦА ЦЕНТРАЛЬНАЯ, 13",
		"ChiefName": "Николаев Вадим Владимирович",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(495) 541-51-11"
		}]
	}],
	"ObjectAddress": [{
		"PostalCode": "142700",
		"Address": "Московская область, район Видное, улица Центральная, дом 13",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "частично",
			"available_z": "частично",
			"available_s": "полностью",
			"available_element": [{
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона у раковины для кресла-коляски",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона рядом с унитазом",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "тактильная полоса перед входной лестницей",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "контрастная маркировка ступеней",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "информационные указатели",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(495) 541-51-11"
	}],
	"ChiefName": "Николаев Вадим Владимирович",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "09:00-17:45"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "09:00-17:45"
	}, {
		"DayWeek": "среда",
		"WorkHours": "09:00-17:45"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "09:00-17:45"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "09:00-16:30"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "выходной"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "выходной"
	}],
	"ClarificationWorkingHours": "Перерыв 13:00 - 13:30 \n\nРежим работы учреждения: круглосуточно \n\n\n",
	"WebSite": "pni10-msk.ru",
	"global_id": 1019362408,
	"geoData": {
		"coordinates": [
			[37.688562037757, 55.542393480997]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [37.688562037757, 55.542393480997],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "Психоневрологический интернат № 33",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 33 Департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ГБУ ПНИ № 33",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 33 Департамента труда и социальной защиты населения города Москвы.",
		"INN": "5031012693",
		"KPP": "503101001",
		"OGRN": "1035006108444",
		"LegalAddress": "142435, ОБЛАСТЬ МОСКОВСКАЯ, ГОРОД НОГИНСК, СЕЛО КУДИНОВО, УЛИЦА ЦЕНТРАЛЬНАЯ, 50",
		"ChiefName": "Большаков Юрий Алексеевич",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(495) 972-97-60"
		}]
	}],
	"ObjectAddress": [{
		"PostalCode": "142435",
		"Address": "Московская область, Ногинский район, село Кудиново, ул. Центральная, 50",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "частично",
			"available_z": "частично",
			"available_s": "полностью",
			"available_element": [{
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "контрастная маркировка ступеней",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "недоступно",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "тактильная полоса перед входной лестницей",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "недоступно",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(495) 972-97-60"
	}, {
		"PublicPhone": "(901) 546-67-56"
	}],
	"ChiefName": "Большаков Юрий Алексеевич",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "08:00-17:00"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "08:00-17:00"
	}, {
		"DayWeek": "среда",
		"WorkHours": "08:00-17:00"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "08:00-17:00"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "08:00-17:00"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "выходной"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "выходной"
	}],
	"ClarificationWorkingHours": "Режим работы учреждения: круглосуточно",
	"WebSite": "pni33.ru",
	"global_id": 1019362410,
	"geoData": {
		"coordinates": [
			[38.208982362747, 55.768589444911]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [38.208982362747, 55.768589444911],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "Психоневрологический интернат № 3",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 3 Департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ГБУ ПНИ № 3",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 3 Департамента труда и социальной защиты населения города Москвы",
		"INN": "5007008047",
		"KPP": "500701001",
		"OGRN": "1035001607189",
		"LegalAddress": "141834, ОБЛАСТЬ МОСКОВСКАЯ, ГОРОД ДМИТРОВ, ПОСЕЛОК ЛУГОВОЙ",
		"ChiefName": "Передельский Сергей Владимирович",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(496) 222-44-03"
		}]
	}],
	"ObjectAddress": [{
		"PostalCode": "141834",
		"Address": "МОСКОВСКАЯ ОБЛАСТЬ, ДМИТРОВСКИЙ РАЙОН, ПОСЕЛОК ЛУГОВОЙ",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "частично",
			"available_z": "частично",
			"available_s": "полностью",
			"available_element": [{
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "контрастная маркировка ступеней",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона рядом с унитазом",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "тактильная полоса перед входной лестницей",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "платформа подъемная (мобильный лестничный подъемник)",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "зона у раковины для кресла-коляски",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "информационные указатели",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(496) 222-44-03"
	}, {
		"PublicPhone": "(496) 222-39-16"
	}, {
		"PublicPhone": "(496) 222-44-00"
	}],
	"ChiefName": "Передельский Сергей Владимирович",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "среда",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "круглосуточно"
	}],
	"ClarificationWorkingHours": "",
	"WebSite": "pni3-mos.ru",
	"global_id": 1019362412,
	"geoData": {
		"coordinates": [
			[37.232863412568, 56.457512180497]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [37.232863412568, 56.457512180497],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "Психоневрологический интернат № 32 им. О.В. Кербикова",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 32 им. О.В. Кербикова Департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ГБУ ПНИ № 32",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 32 им. О.В. Кербикова Департамента труда и социальной защиты населения города Москвы.",
		"INN": "5009014328",
		"KPP": "500901001",
		"OGRN": "1025001278279",
		"LegalAddress": "142044, ОБЛАСТЬ МОСКОВСКАЯ, ГОРОД ДОМОДЕДОВО, СЕЛО ДОБРЫНИХА, 9",
		"ChiefName": "Малиновская Светлана Дмитриевна",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(499) 270-97-80"
		}]
	}],
	"ObjectAddress": [{
		"PostalCode": "142044",
		"Address": "Московская область, городской округ Домодедово, село Добрыниха, 9",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "недоступно",
			"available_o": "частично",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": [{
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "недоступно",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "контрастная маркировка ступеней",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "недоступно",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "тактильная полоса перед входной лестницей",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "недоступно",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "недоступно",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "недоступно",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "платформа подъемная (мобильный лестничный подъемник)",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "недоступно",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(499) 270-98-14"
	}, {
		"PublicPhone": "(499) 270-98-00"
	}, {
		"PublicPhone": "(499) 270-97-80"
	}],
	"ChiefName": "Малиновская Светлана Дмитриевна",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "08:00-17:00"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "08:00-17:00"
	}, {
		"DayWeek": "среда",
		"WorkHours": "08:00-17:00"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "08:00-17:00"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "08:00-17:00"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "выходной"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "выходной"
	}],
	"ClarificationWorkingHours": "Режим работы учреждения: круглосуточно",
	"WebSite": "pni32.ru",
	"global_id": 1019362414,
	"geoData": {
		"coordinates": [
			[37.708305134773, 55.182036523858]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [37.708305134773, 55.182036523858],
		"type": "Point"
	}
}, {
	"Category": "Психоневрологический интернат",
	"CommonName": "Психоневрологический интернат № 13",
	"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 13 Департамента труда и социальной защиты населения города Москвы",
	"ShortName": "ГБУ ПНИ № 13",
	"OrgInfo": [{
		"FullName": "Государственное бюджетное учреждение города Москвы Психоневрологический интернат № 13 Департамента труда и социальной защиты населения города Москвы.",
		"INN": "5045015550",
		"KPP": "504501001",
		"OGRN": "1035009150714",
		"LegalAddress": "142817, ОБЛАСТЬ МОСКОВСКАЯ, ГОРОД СТУПИНО, СЕЛО ЛУЖНИКИ, ТЕРРИТОРИЯ ПНИ N 13",
		"ChiefName": "Хромов Дмитрий Николаевич",
		"ChiefPosition": "директор",
		"ChiefPhone": [{
			"ChiefPhone": "(496) 642-66-68"
		}, {
			"ChiefPhone": "(496) 642-38-22"
		}]
	}],
	"ObjectAddress": [{
		"PostalCode": "142817",
		"Address": "Московская область, Ступинский район, с. Лужники, ул. ПНИ 13",
		"SocialServices": "Социальное обслуживание в стационарной форме",
		"Availability": [{
			"available_k": "частично",
			"available_o": "частично",
			"available_z": "частично",
			"available_s": "частично",
			"available_element": [{
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "тактильное обозначение санузла",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "ширина двери",
				"available_degree": "недоступно",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "ширина дверей в кабинеты",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "тактильная полоса перед входной лестницей",
				"available_degree": "частично",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручни у унитаза",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "платформа подъемная (мобильный лестничный подъемник)",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие указателей, пиктограмм",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "ширина полосы движения",
				"available_degree": "частично",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "габариты зоны сидения (глубина)",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лифт",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "ширина входной двери",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "визуальные средства информации о предоставлении услуги",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "поручень у раковины",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по слуху",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "наличие надписей",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "зона оказания услуги",
				"Element_mgn": "тактильные средства информации",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "информационные указатели",
				"available_degree": "полностью",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "входная группа",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "полностью",
				"available_index": "соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "пандус с поручнями и его уклон",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "пути движения и эвакуации",
				"Element_mgn": "лестницы на пути движения",
				"available_degree": "полностью",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "поручни на имеющейся лестнице",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды по зрению",
				"Area_mgn": "входная группа",
				"Element_mgn": "нулевой вход",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "безбарьерный путь до главного входа",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "санитарный узел",
				"Element_mgn": "габариты кабины",
				"available_degree": "недоступно",
				"available_index": "не соответствует"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "информационные указатели",
				"available_degree": "частично",
				"available_index": "нет"
			}, {
				"Group_mgn": "инвалиды-колясочники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "частично",
				"available_index": "есть"
			}, {
				"Group_mgn": "инвалиды-опорники",
				"Area_mgn": "территория объекта",
				"Element_mgn": "машино-место для инвалидов",
				"available_degree": "полностью",
				"available_index": "есть"
			}]
		}]
	}],
	"ChiefPosition": "директор",
	"PublicPhone": [{
		"PublicPhone": "(496) 642-38-22"
	}, {
		"PublicPhone": "(496) 642-66-68"
	}, {
		"PublicPhone": "(496) 642-38-71"
	}],
	"ChiefName": "Хромов Дмитрий Николаевич",
	"WorkingHours": [{
		"DayWeek": "понедельник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "вторник",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "среда",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "четверг",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "пятница",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "суббота",
		"WorkHours": "круглосуточно"
	}, {
		"DayWeek": "воскресенье",
		"WorkHours": "круглосуточно"
	}],
	"ClarificationWorkingHours": "Режим работы сотрудников администрации ГБУ ПНИ №13\nПонедельник — пятница: с 08.00 ч. до 16.00 ч. - женщины; с 08.00 ч. до 17.00 ч. - мужчины\nОбед: с 13.00 до 14.00\nСуббота — воскресенье: выходной\n\nРежим работы врачей ГБУ ПНИ №13\nПонедельник — пятница: с 08.00 ч. до 15.42 ч.\nОбед: с 13.30 до 14.00\nСуббота — воскресенье (дежурный врач): с 08.00 ч. до 17.00 ч.",
	"WebSite": "pni13.ru",
	"global_id": 1019362417,
	"geoData": {
		"coordinates": [
			[38.078937839129, 54.844634138906]
		],
		"type": "MultiPoint"
	},
	"geodata_center": {
		"coordinates": [38.078937839129, 54.844634138906],
		"type": "Point"
	}
}]