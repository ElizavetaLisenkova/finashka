#!/bin/bash
ps aux > ps.out.txt
sort ps.out.txt > sorted.ps.txt
cut -d" " -f1 sorted.ps.txt | uniq > userslist.txt
file="/home/lisenkova/bin/userslist.txt"
echo "<html> <title>PROCESSES STATISTICS</title> <body> <h1> DISTRIBUTION OF PROCESSES BY USERS</h1>" > index.html
for user in $(cat $file)
do
grep ^$user sorted.ps.txt > $user.ps.txt
sed -e "s/$user/<li> $user/g" $user.ps.txt > $user.html
echo "<p><b>TOTAL PROCESSES: $(cat $user.html | wc -l) </b></p>" > $user.total.txt
echo "$(cat $user.total.txt) $(cat $user.html) <hr noshade>" >> index.html
done
echo "</body></html>" >> index.html
