#install.packages("expm")
library(expm)

#создадим вектор
p = c(0,0,0,0,0,0,0.5,0,0,0,0,0,0,0,
      0,0,0.38,0,0,0.51,0,0,0,0,0,0,0,0,
      0,0.28,0,0,0,0,0.04,0,0,0,0,0,0,0,
      0,0,0.08,0,0.84,0,0,0,0,0,0,0,0,0,
      0.47,0,0.1,0.07,0,0,0,0,0.01,0,0,0,0,0,
      0,0.2,0.12,0,0.24,0,0,0,0.11,0.11,0.2,0,0,0,
      0,0.05,0.05,0,0,0.24,0,0.07,0.12,0,0.18,0.16,0,0,
      0,0,0,0,0,0,0,0,0,0,0,0,0.8,0,
      0,0,0,0,0,0.23,0.07,0,0,0,0,0,0.29,0.21,
      0,0,0,0,0,0,0,0,0.3,0,0,0,0.16,0.48,
      0,0,0,0,0.14,0,0,0,0,0,0,0.34,0.3,0.06,
      0,0,0,0,0.31,0.21,0.25,0,0,0,0,0,0,0.06,
      0,0,0,0,0,0,0,0,0,0,0.31,0.03,0,0,
      0,0,0,0,0,0,0,0,0.07,0,0.23,0.28,0.04,0)
#преобразуем его в матрицу, byrow=True - по строкам
p = matrix(p, nrow = 14, ncol=14, byrow = T)
#Заполним диагонали остатками от единицы вычесть сумму строки.
for(i in 1:14)
{
  p[i,i]=1-sum(p[i,])
}

print(p)



#1
#копируем матрицу
p1=p

for(i in 1:6) # делаем 7 шагов
{
  p1=p1%*%p
}

res1=p1[7, 12]
print(res1)
  


#2
p2 = p
a = c(0.12,0.02,0.1,0.13,0.08,0.05,0.12,0.08,0.06,0.02,0.03,0.09,0.05,0.05)
#возводим в 10 степень
p2 = p2 %^% 10
#перемножаем
res2 = a %*% p2
print(res2)



#3
multiply=function(p1,p2)
{
  res=matrix(0, nrow = dim(p1)[1], ncol = dim(p1)[2])
  for(i in 1:dim(p1)[1])
  {
    for(j in 1:dim(p1)[2])
    {
      for(m in 1: dim(p2)[1])
      {
        if(m!=j)
        {
          res[i,j]=res[i,j]+p1[i,m]*p2[m,j]
        }
      }
    }
  }
  return(res)
}


p_first=function(p,k)
{
  p0=p
  for(t in 1:k)
  {
    p0=multiply(p,p0)
  }
  return(p0)
}

p3=p_first(p,5)
res3=p3[7,9]
print(res3)

#4
p4=p
for (t in 2:5){
  p4=p4+p_first(p, t)
}
res4=p4[3,10]
print(res4)

#5
p5 = p
for (t in 2:500)
    p5 = p5 + t * p_first(p, t)
res5=p5[14, 13]
print(res5)


#6
first_return=function(p,step_k)
{
  if (step_k<=1) return(p)
  else
  {
    pf=array(dim = c(dim(p), step_k))
    for (i in 1:step_k)
    {
      t_p=p
      for(j in 1:(i-1))
      {
        t_p=t_p%*%p
      }
      pf[,,i]=t_p
    }
    f=pf
    for (k in 2:step_k)
    {
      for (m in 1:(k-1))
      {
        f[,,k]=f[,,k]-f[,,m]*pf[,,k-m]
      }
    }
    return(f[,,step_k])
  }
}

p6=first_return(p,8)
res6=p6[9,9]
print(res6)
#7
p7=p
for (t in 2:8)
  p7=p7+first_return(p, t)
res7=p7[1,1]
print(res7)
#8
p8=p
for (t in 2:500)
  p8=p8+t*first_return(p, t)
res8=p8[12,12]
print(res8)
#9
ed=matrix(0, nrow = dim(p)[1], ncol = dim(p)[2])
for(i in 1:dim(ed)[1])
{
  ed[i,i]=1
}
p9=p
p9=p9-ed
p9=t(p9)
for(i in 1:dim(p9)[2])
{
  p9[14,i]=1
}
B=c(rep(0, times = (dim(p9)[1]-1)), 1)
res9=solve(p9)%*%B
print(res9)
print(sum(res9))

#------------------------------------------------------------------------------
#2 ЗАДАНИЕ

lambda <- 42
m <- 2
mu <- 31
n <- 10 

#создадим матрицу интенсивностей переходов
matrix_L <- matrix(0, nrow = (m + n + 1), ncol = (m + n + 1))
for (i in 1:(m+n)) 
  matrix_L[i, i+1]= lambda
for (i in 2:m) 
  matrix_L[i, i-1] = (i - 1) * mu
for (i in (m+1):(m+n+1))
  matrix_L[i, i-1] = m * mu
 
print(matrix_L)

#a)
ss_prob <- function(x)  
{
  for (i in 1:dim(x)[1]){
    x[i,i] = -sum(x[i,]) 
  }
  M = t(x)
  M[dim(M), ] = rep(1, times = dim(M)[1]) 
  B = double(dim(M)[1])
  B[dim(M)[1]] <- 1
  S = solve(M) %*% B 
  return(S)
}

result = ss_prob(matrix_L)
print(result)

#b)
p_otkaza = result[length(result)]
print(p_otkaza)

#c)
otn_pr_sp = 1 - result[length(result)]
abs_pr_sp = otn_pr_sp*lambda

print(otn_pr_sp)
print(abs_pr_sp)

#d)
mid = 0
for (i in 1:n)
  mid = mid + (i * result[m+i,])
print(mid)

#e)
middle_time = 0
for (i in 0:(n-1))
  middle_time = middle_time + (i + 1)/ (m * mu)* result[m + i,]
print(middle_time)

#f)
chan = 0
for (i in 1:m)
  chan <- chan + (i * result[i,])
for (i in (m+1):(m+n))
  chan <- chan + (m * result[i,])
print(chan)

#g)
q = 0
for (i in 1:m)
  q = q + result[i,]
print(q)


#h)
downtime = 1/lambda
print(downtime)

