
<html>
<head>
<meta charset="UTF-8">
</head>
<body>
<?php
define ("koeff",60);
$h=3.5;
echo " Число минут в указанном значении в часах =".$h*koeff."<br>";
echo PHP_VERSION; 
?>
</body></html>

