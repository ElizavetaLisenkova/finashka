<html>
<meta charset="UTF-8">
<body>
<?php
echo "Привет   ".$_GET['name_of_user'];
?>
</body></html>
