<html>
<meta charset="UTF-8">
<body>
<?php
if ($_GET['name_of_user'] == "123")
   echo "Привет   ";
else
     echo "Ошибка ";
?>
</body></html>
