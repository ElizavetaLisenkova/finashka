<html><head>
<meta charset="UTF-8">
<title> Первая программа </title>
</head><body>
<?php
    echo " <B>Начало</B> <I> создания</I> <br>сайта по
     информационным технологиям ";
?>	
</body></html>

