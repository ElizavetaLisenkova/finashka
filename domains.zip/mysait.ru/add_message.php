<meta charset="UTF-8">
<?php
if (isset($_POST['okbutton']))
{
 if ($_POST['name_of_quest']=='')
      exit("Введите имя <a href=’questbook.php’>Назад!</a>");
 if ($_POST['message_of_quest']=='')
   exit("Введите сообщение <a href='questbook.php'>Назад!</a>");
 $f=fopen("gost.txt","at") or die("Не могу открыть файл");
 flock($f,2);
 fputs($f,$_POST['name_of_quest']."\n");
 fputs($f,$_POST['message_of_quest']."\n");
 flock($f,3);
 fclose($f);
 }
header('location:questbook.php');
?> 
