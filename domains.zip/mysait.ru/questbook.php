<html><head>
    <meta charset="UTF-8">
<title> Гостевая книга </title></head>
<body>
<form action="add_message.php" method="post">
Имя <br>
<input type="text" name="name_of_quest">
<br>Сообщение:<br>
<br>
<textarea name="message_of_quest" cols=10 rows=5>
</textarea>
<br><input type="submit" name="okbutton" value="OK">
</form>
<?php
$f=fopen("gost.txt","rt") or die("Не могу открыть файл");
while (!feof($f))
{
$data=fgets($f); // Получаем фамилию
echo "<small>Имя:</small>".$data."<br>";
$data=fgets($f); // Получаем сообщение
echo "<small>Сообщение:</small>".$data."<br>";
echo "<hr>";
}
fclose($f);
?> 
