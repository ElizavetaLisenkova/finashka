<html><head>
<meta charset="UTF-8">
</head><body>
<?php
$a="НГЛУ";
echo " <B> факультет</B><br>".$a." <br>
<I>Н.Новгород</I>";
?>
</body></html>
