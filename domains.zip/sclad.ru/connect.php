<meta charset="UTF-8">
<?php
$sqlhost="localhost";
$sqluser="mysql";
$sqlpass="mysql";
$db="Firma";
mysql_connect($sqlhost,$sqluser,$sqlpass) or die("MySQL не доступен! ".mysql_error());
mysql_select_db($db) or die("Нет соединения с базой данных".mysql_error());
?>
